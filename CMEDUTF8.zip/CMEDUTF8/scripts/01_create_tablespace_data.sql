-- ============================================================================
-- Script: 01_create_tablespace_data.sql
-- Description: Creation du tablespace DATA avec 3 datafiles (50GB total)
-- ============================================================================
-- Ce script est GENERIQUE et fonctionne pour n'importe quelle base Oracle
-- - Trouve automatiquement le PDB (pas besoin de hardcoder le nom)
-- - Utilise le ORACLE_SID dynamiquement (pas de CMEDUTF8 en dur)
-- - Le tablespace est cree dans le PDB (et non dans le CDB$ROOT)
-- ============================================================================

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ECHO ON
SET SERVEROUTPUT ON
SET VERIFY OFF

PROMPT
PROMPT ========================================
PROMPT Recherche automatique du PDB
PROMPT ========================================
PROMPT

-- Recuperation automatique du premier PDB disponible
-- (excluant PDB$SEED qui est un template)
COLUMN pdb_name NEW_VALUE target_pdb NOPRINT
SELECT name as pdb_name
FROM v$pdbs
WHERE name NOT IN ('PDB$SEED', 'CDB$ROOT')
  AND open_mode = 'READ WRITE'
ORDER BY con_id
FETCH FIRST 1 ROWS ONLY;

PROMPT PDB cible trouve : &target_pdb
PROMPT

PROMPT ========================================
PROMPT Connexion au PDB pour creer le tablespace
PROMPT ========================================
PROMPT

-- IMPORTANT: Se connecter au PDB (pas au CDB$ROOT)
-- Les tablespaces applicatifs doivent etre dans le PDB
ALTER SESSION SET CONTAINER = &target_pdb;

PROMPT Connecte au conteneur : &target_pdb
PROMPT

PROMPT ========================================
PROMPT Creation du tablespace DATA dans le PDB
PROMPT ========================================
PROMPT

-- Recuperation du SID (nom de la base) depuis la base de donnees
COLUMN db_name NEW_VALUE oracle_sid NOPRINT
SELECT SYS_CONTEXT('USERENV', 'DB_NAME') as db_name FROM dual;

PROMPT Nom de la base (SID) : &oracle_sid
PROMPT Nom du PDB : &target_pdb
PROMPT

-- Creation du tablespace DATA avec le premier datafile (30GB)
-- IMPORTANT: Les fichiers du PDB vont dans /opt/oracle/oradata/SID/PDB/
-- Cela suit les bonnes pratiques Oracle et separe CDB et PDB
CREATE TABLESPACE DATA
  DATAFILE '/opt/oracle/oradata/&oracle_sid/&target_pdb/data01.dbf'
  SIZE 30G
  AUTOEXTEND ON
  NEXT 1M
  EXTENT MANAGEMENT LOCAL
  SEGMENT SPACE MANAGEMENT AUTO;

PROMPT Datafile 1 cree : /opt/oracle/oradata/&oracle_sid/&target_pdb/data01.dbf (30GB, AUTOEXTEND ON)

-- Ajout du deuxieme datafile (10GB)
ALTER TABLESPACE DATA
  ADD DATAFILE '/opt/oracle/oradata/&oracle_sid/&target_pdb/data02.dbf'
  SIZE 10G;

PROMPT Datafile 2 ajoute : /opt/oracle/oradata/&oracle_sid/&target_pdb/data02.dbf (10GB)

-- Ajout du troisieme datafile (10GB)
ALTER TABLESPACE DATA
  ADD DATAFILE '/opt/oracle/oradata/&oracle_sid/&target_pdb/data03.dbf'
  SIZE 10G;

PROMPT Datafile 3 ajoute : /opt/oracle/oradata/&oracle_sid/&target_pdb/data03.dbf (10GB)

PROMPT
PROMPT ========================================
PROMPT Verification du tablespace DATA
PROMPT ========================================
PROMPT

SET LINESIZE 200
SET PAGESIZE 100
COLUMN tablespace_name FORMAT A15
COLUMN file_name FORMAT A65
COLUMN size_gb FORMAT 999.99
COLUMN autoextensible FORMAT A5
COLUMN status FORMAT A10

SELECT
  tablespace_name,
  file_name,
  bytes/1024/1024/1024 as size_gb,
  autoextensible,
  status
FROM dba_data_files
WHERE tablespace_name = 'DATA'
ORDER BY file_id;

PROMPT
PROMPT ========================================
PROMPT Tablespace DATA cree avec succes dans le PDB!
PROMPT Container (PDB) : &target_pdb
PROMPT Base de donnees (SID) : &oracle_sid
PROMPT Total : 50GB (30GB + 10GB + 10GB)
PROMPT ========================================
PROMPT

EXIT;
