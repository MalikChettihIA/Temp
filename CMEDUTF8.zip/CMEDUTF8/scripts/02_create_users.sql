-- ============================================================================
-- Script: 02_create_users.sql
-- Description: Creation des utilisateurs OP, OPREPORTS, OPPAYMENTS
-- ============================================================================
-- Ce script est GENERIQUE et fonctionne pour n'importe quelle base Oracle
-- - Trouve automatiquement le PDB
-- - Se connecte au PDB pour creer les utilisateurs
-- ============================================================================

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ECHO ON
SET SERVEROUTPUT ON
SET VERIFY OFF

PROMPT
PROMPT ========================================
PROMPT Recherche automatique du PDB
PROMPT ========================================
PROMPT

-- Recuperation automatique du premier PDB disponible
COLUMN pdb_name NEW_VALUE target_pdb NOPRINT
SELECT name as pdb_name
FROM v$pdbs
WHERE name NOT IN ('PDB$SEED', 'CDB$ROOT')
  AND open_mode = 'READ WRITE'
ORDER BY con_id
FETCH FIRST 1 ROWS ONLY;

PROMPT PDB cible trouve : &target_pdb
PROMPT

PROMPT ========================================
PROMPT Connexion au PDB
PROMPT ========================================
PROMPT

-- Connexion au PDB (les utilisateurs applicatifs doivent etre dans le PDB)
ALTER SESSION SET CONTAINER = &target_pdb;

PROMPT Connecte au conteneur : &target_pdb
PROMPT

-- Permettre la creation d'utilisateurs sans prefixe C## dans le PDB
ALTER SESSION SET "_ORACLE_SCRIPT"=true;

PROMPT
PROMPT ========================================
PROMPT Creation des roles personnalises
PROMPT ========================================
PROMPT

-- Suppression des roles s'ils existent (pour permettre la re-execution)
BEGIN
   FOR r IN (SELECT role FROM dba_roles WHERE role IN ('OP_USER', 'OP_WRITER', 'OP_DBA')) LOOP
      EXECUTE IMMEDIATE 'DROP ROLE ' || r.role;
   END LOOP;
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Creation des roles
CREATE ROLE op_user NOT IDENTIFIED;
CREATE ROLE op_writer NOT IDENTIFIED;
CREATE ROLE op_dba NOT IDENTIFIED;

PROMPT Roles op_user, op_writer, op_dba crees

-- Privileges pour le role op_dba
GRANT CREATE PROCEDURE TO op_dba;
GRANT CREATE TABLE TO op_dba;
GRANT CREATE TRIGGER TO op_dba;
GRANT CREATE USER TO op_dba;
GRANT ALTER USER TO op_dba;
GRANT DROP USER TO op_dba;
GRANT CREATE VIEW TO op_dba;
GRANT CREATE SEQUENCE TO op_dba;

PROMPT Privileges accordes au role op_dba

-- Privileges pour le role op_user
GRANT SELECT ON sys.dba_free_space TO op_user;
GRANT CREATE SESSION TO op_user;

PROMPT Privileges accordes au role op_user

PROMPT
PROMPT ========================================
PROMPT Configuration du profil et systeme
PROMPT ========================================
PROMPT

-- Permettre un nombre illimite de sessions par utilisateur
ALTER PROFILE DEFAULT LIMIT sessions_per_user UNLIMITED;

PROMPT Profil DEFAULT modifie : sessions_per_user = UNLIMITED

-- Configuration systeme
ALTER SYSTEM SET "_fix_control"='17376322:OFF' SCOPE=BOTH;

PROMPT Parametre systeme _fix_control configure

-- Creation du profil de securite pour les utilisateurs
BEGIN
   EXECUTE IMMEDIATE 'DROP PROFILE SECU_USER_TIME CASCADE';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

CREATE PROFILE SECU_USER_TIME LIMIT
  password_life_time UNLIMITED
  password_reuse_max 1
  password_grace_time UNLIMITED;

PROMPT Profil SECU_USER_TIME cree

PROMPT
PROMPT ========================================
PROMPT Creation de l utilisateur OP
PROMPT ========================================
PROMPT

-- Suppression de l'utilisateur OP s'il existe
BEGIN
   EXECUTE IMMEDIATE 'DROP USER OP CASCADE';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Creation de l'utilisateur OP
CREATE USER OP
  IDENTIFIED BY cashflow
  DEFAULT TABLESPACE DATA
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  QUOTA UNLIMITED ON DATA;

PROMPT Utilisateur OP cree

-- Privileges pour OP
GRANT DEBUG CONNECT SESSION TO OP;
GRANT op_dba TO OP WITH ADMIN OPTION;
GRANT op_user TO OP WITH ADMIN OPTION;
GRANT op_writer TO OP WITH ADMIN OPTION;
GRANT SELECT ON v_$session TO OP WITH GRANT OPTION;
GRANT ALTER SYSTEM TO OP;
GRANT CREATE USER TO OP;
GRANT ALTER USER TO OP;
GRANT EXECUTE ON DBMS_OBFUSCATION_TOOLKIT.MD5 TO OP;
GRANT EXECUTE ON DBMS_OBFUSCATION_TOOLKIT.DES3ENCRYPT TO OP;

PROMPT Privileges accordes a OP

PROMPT
PROMPT ========================================
PROMPT Creation de l utilisateur OPREPORTS
PROMPT ========================================
PROMPT

-- Suppression de l utilisateur OPREPORTS s il existe
BEGIN
   EXECUTE IMMEDIATE 'DROP USER OPREPORTS CASCADE';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Creation de l'utilisateur OPREPORTS
CREATE USER OPREPORTS
  IDENTIFIED BY cashflow
  DEFAULT TABLESPACE DATA
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  QUOTA UNLIMITED ON DATA;

PROMPT Utilisateur OPREPORTS cree

-- Grant role privileges
GRANT CONNECT TO OPREPORTS;
GRANT op_user TO OPREPORTS WITH ADMIN OPTION;
GRANT op_writer TO OPREPORTS WITH ADMIN OPTION;
GRANT RESOURCE TO OPREPORTS;
GRANT DEBUG CONNECT SESSION TO OPREPORTS;

-- Grant system privileges
GRANT CREATE ANY PROCEDURE TO OPREPORTS;
GRANT CREATE ANY TABLE TO OPREPORTS;
GRANT CREATE ANY VIEW TO OPREPORTS;
GRANT EXECUTE ANY PROCEDURE TO OPREPORTS;
GRANT GRANT ANY PRIVILEGE TO OPREPORTS;
GRANT GRANT ANY ROLE TO OPREPORTS;
GRANT SELECT ANY TABLE TO OPREPORTS;
GRANT UNLIMITED TABLESPACE TO OPREPORTS;
GRANT SELECT ON dba_users TO OPREPORTS;
GRANT CREATE USER TO OPREPORTS;
GRANT ALTER USER TO OPREPORTS;
GRANT ALTER SYSTEM TO OPREPORTS;
GRANT SELECT ON DBA_USERS TO OPREPORTS;

PROMPT Privileges accordes a OPREPORTS

PROMPT
PROMPT ========================================
PROMPT Creation de l utilisateur OPPAYMENTS
PROMPT ========================================
PROMPT

-- Suppression de l'utilisateur OPPAYMENTS s'il existe
BEGIN
   EXECUTE IMMEDIATE 'DROP USER OPPAYMENTS CASCADE';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Creation de l'utilisateur OPPAYMENTS
CREATE USER OPPAYMENTS
  IDENTIFIED BY cashflow
  DEFAULT TABLESPACE DATA
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  QUOTA UNLIMITED ON DATA;

PROMPT Utilisateur OPPAYMENTS cree

-- Grant role privileges
GRANT CONNECT TO OPPAYMENTS;
GRANT op_user TO OPPAYMENTS WITH ADMIN OPTION;
GRANT op_writer TO OPPAYMENTS WITH ADMIN OPTION;
GRANT RESOURCE TO OPPAYMENTS;
GRANT DEBUG CONNECT SESSION TO OPPAYMENTS;

-- Grant system privileges
GRANT CREATE ANY PROCEDURE TO OPPAYMENTS;
GRANT CREATE ANY TABLE TO OPPAYMENTS;
GRANT CREATE ANY VIEW TO OPPAYMENTS;
GRANT EXECUTE ANY PROCEDURE TO OPPAYMENTS;
GRANT GRANT ANY PRIVILEGE TO OPPAYMENTS;
GRANT GRANT ANY ROLE TO OPPAYMENTS;
GRANT SELECT ANY TABLE TO OPPAYMENTS;
GRANT UNLIMITED TABLESPACE TO OPPAYMENTS;
GRANT CREATE USER TO OPPAYMENTS;
GRANT ALTER USER TO OPPAYMENTS;
GRANT ALTER SYSTEM TO OPPAYMENTS;
GRANT SELECT ON DBA_USERS TO OPPAYMENTS;

PROMPT Privileges accordes a OPPAYMENTS

PROMPT
PROMPT ========================================
PROMPT Verification des utilisateurs crees
PROMPT ========================================
PROMPT

SET LINESIZE 200
SET PAGESIZE 100
COLUMN username FORMAT A20
COLUMN default_tablespace FORMAT A20
COLUMN account_status FORMAT A20
COLUMN profile FORMAT A20

SELECT username, default_tablespace, account_status, profile
FROM dba_users
WHERE username IN ('OP', 'OPREPORTS', 'OPPAYMENTS')
ORDER BY username;

PROMPT
PROMPT ========================================
PROMPT Verification des roles
PROMPT ========================================
PROMPT

COLUMN role FORMAT A20
SELECT role FROM dba_roles
WHERE role IN ('OP_USER', 'OP_WRITER', 'OP_DBA')
ORDER BY role;

PROMPT
PROMPT ========================================
PROMPT Utilisateurs crees avec succes!
PROMPT - OP (mot de passe: cashflow)
PROMPT - OPREPORTS (mot de passe: cashflow)
PROMPT - OPPAYMENTS (mot de passe: cashflow)
PROMPT ========================================
PROMPT

EXIT;
