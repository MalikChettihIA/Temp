-- ============================================================================
-- Script: 03_create_directory.sql
-- Description: Creation du DIRECTORY IMP_DIR pour imports/exports
-- ============================================================================
-- Ce script est GENERIQUE et fonctionne pour n'importe quelle base Oracle
-- - Trouve automatiquement le PDB
-- - Cree le directory dans le PDB
-- ============================================================================

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ECHO ON
SET SERVEROUTPUT ON
SET VERIFY OFF

PROMPT
PROMPT ========================================
PROMPT Recherche automatique du PDB
PROMPT ========================================
PROMPT

-- Recuperation automatique du premier PDB disponible
COLUMN pdb_name NEW_VALUE target_pdb NOPRINT
SELECT name as pdb_name
FROM v$pdbs
WHERE name NOT IN ('PDB$SEED', 'CDB$ROOT')
  AND open_mode = 'READ WRITE'
ORDER BY con_id
FETCH FIRST 1 ROWS ONLY;

PROMPT PDB cible trouve : &target_pdb
PROMPT

PROMPT ========================================
PROMPT Connexion au PDB
PROMPT ========================================
PROMPT

-- Connexion au PDB (les directories doivent etre dans le PDB)
ALTER SESSION SET CONTAINER = &target_pdb;

PROMPT Connecte au conteneur : &target_pdb
PROMPT

PROMPT ========================================
PROMPT Creation du DIRECTORY IMP_DIR
PROMPT ========================================
PROMPT

-- Suppression du directory s'il existe
BEGIN
   EXECUTE IMMEDIATE 'DROP DIRECTORY IMP_DIR';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Creation du directory pour imports/exports
CREATE OR REPLACE DIRECTORY IMP_DIR AS '/opt/oracle/scripts/setup/imp_dir';

PROMPT Directory IMP_DIR cree : /opt/oracle/scripts/setup/imp_dir

PROMPT
PROMPT ========================================
PROMPT Verification du DIRECTORY
PROMPT ========================================
PROMPT

SET LINESIZE 200
SET PAGESIZE 100
COLUMN directory_name FORMAT A20
COLUMN directory_path FORMAT A60

SELECT directory_name, directory_path
FROM dba_directories
WHERE directory_name = 'IMP_DIR';

PROMPT
PROMPT ========================================
PROMPT Directory IMP_DIR cree avec succes!
PROMPT Chemin : /opt/oracle/scripts/setup/imp_dir
PROMPT ========================================
PROMPT

EXIT;
