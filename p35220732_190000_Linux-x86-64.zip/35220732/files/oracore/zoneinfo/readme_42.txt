Current Structure version: 3
Current Content Version  :42

Content Version 42
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
42, Africa/Cairo, 2023,
42, Africa/Casablanca, 2023, 2023
42, Africa/Casablanca, 2031, 2031
42, Africa/Casablanca, 2038, 2038
42, Africa/Casablanca, 2046, 2046
42, Africa/Casablanca, 2054, 2054
42, Africa/Casablanca, 2062, 2062
42, Africa/Casablanca, 2069, 2069
42, Africa/Casablanca, 2077, 2077
42, Africa/El_Aaiun, 2023, 2023
42, Africa/El_Aaiun, 2031, 2031
42, Africa/El_Aaiun, 2038, 2038
42, Africa/El_Aaiun, 2046, 2046
42, Africa/El_Aaiun, 2054, 2054
42, Africa/El_Aaiun, 2062, 2062
42, Africa/El_Aaiun, 2069, 2069
42, Africa/El_Aaiun, 2077, 2077
42, America/Yellowknife, 1800, 1972
42, America/Godthab, 2023,
42, Asia/Gaza, 2023, 2025
42, Asia/Gaza, 2036, 2057
42, Asia/Gaza, 2068,
42, Asia/Hebron, 2023, 2025
42, Asia/Hebron, 2036, 2057
42, Asia/Hebron, 2068,
42, America/Nuuk, 2023,
42, Egypt, 2023,
------ End of updates in Content version 42 ----

Current Structure version: 3
Current Content Version  :41

Content Version 41
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
41, America/Ojinaga, 2022,
41, America/Bahia_Banderas, 2023,
41, America/Thunder_Bay, 1800, 1970
41, America/Thunder_Bay, 1973, 1974
41, America/Nipigon, 1800, 1974
41, America/Rainy_River, 1800, 2005
41, America/Pangnirtung, 1921, 1995
41, America/Iqaluit, 1965, 1980
41, America/Rankin_Inlet, 1965, 1980
41, America/Cambridge_Bay, 1965, 1980
41, America/Yellowknife, 1965, 1980
41, America/Inuvik, 1965, 1980
41, America/Whitehorse, 1966, 1967
41, America/Mexico_City, 2023,
41, America/Chihuahua, 2022,
41, America/Mazatlan, 2023,
41, America/Bogota, 1993,
41, America/Godthab, 2023,
41, America/Resolute, 1965, 1980
41, America/Merida, 2023,
41, America/Monterrey, 2023,
41, Asia/Kuala_Lumpur, 1981,
41, Asia/Singapore, 1981,
41, America/Nuuk, 2023,
41, Pacific/Fiji, 2022,
41, Canada/Yukon, 1966, 1967
41, Mexico/General, 2023,
41, Mexico/BajaSur, 2023,
41, Singapore, 1981,

Timezones added:
America/Ciudad_Juarez

------ End of updates in Content version 41 ----

Current Structure version: 3
Current Content Version  :40

Content Version 40 
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
40, America/Matamoros, 1800, 1800
40, America/Ojinaga, 1931, 1931
40, America/Bahia_Banderas, 1931, 1931
40, America/Santa_Isabel, 1922, 1922
40, America/Mexico_City, 1931, 1931
40, America/Chihuahua, 1931, 1931
40, America/Hermosillo, 1931, 1931
40, America/Mazatlan, 1931, 1931
40, America/Tijuana, 1922, 1922
40, Asia/Amman, 2022,
40, Asia/Gaza, 2022,
40, Asia/Damascus, 2022,
40, Asia/Hebron, 2022,
40, Europe/Uzhgorod, 1800, 1981
40, Europe/Uzhgorod, 1990, 1991
40, Europe/Zaporozhye, 1800, 1943
40, Europe/Zaporozhye, 1990, 1991
40, Mexico/General, 1931, 1931
40, Mexico/BajaSur, 1931, 1931
40, America/Ensenada, 1922, 1922
40, Mexico/BajaNorte, 1922, 1922

------ End of updates in Content version 40 ----

Current Structure version: 3
Current Content Version  :39

Content Version 39
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
39, Antarctica/Vostok, 1800,
39, America/Santiago, 1946, 1946
39, America/Santiago, 2022, 2022
39, Pacific/Chuuk, 1800,
39, Pacific/Pohnpei, 1800,
39, Asia/Brunei, 1800,
39, Asia/Tehran, 1935, 1979
39, Asia/Tehran, 2023,
39, Asia/Kuala_Lumpur, 1800, 1900
39, Asia/Saigon, 1800, 1906
39, Atlantic/Reykjavik, 1800,
39, Europe/Dublin, 1800, 1880
39, Europe/Copenhagen, 1800, 1940
39, Europe/Copenhagen, 1945, 1980
39, Europe/Luxembourg, 1800, 1929
39, Europe/Luxembourg, 1940, 1940
39, Europe/Luxembourg, 1944, 1944
39, America/Punta_Arenas, 1946, 1947
39, Europe/Monaco, 1800, 1911
39, Europe/Monaco, 1940, 1944
39, Europe/Amsterdam, 1800, 1942
39, Europe/Amsterdam, 1944, 1977
39, Europe/Oslo, 1800, 1940
39, Europe/Oslo, 1945, 1980
39, Europe/Stockholm, 1800, 1980
39, Europe/Simferopol, 1994, 1995
39, Indian/Kerguelen, 1800,
39, Indian/Christmas, 1800,
39, Indian/Cocos, 1800,
39, Indian/Mahe, 1800,
39, Indian/Reunion, 1800,
39, Pacific/Easter, 2022, 2022
39, Pacific/Majuro, 1800,
39, Pacific/Truk, 1800,
39, Pacific/Ponape, 1800,
39, Pacific/Funafuti, 1800,
39, Pacific/Wake, 1800,
39, Pacific/Wallis, 1800,
39, Chile/Continental, 1946, 1946
39, Chile/Continental, 2022, 2022
39, Iran, 1935, 1979
39, Iran, 2023,
39, Asia/Ho_Chi_Minh, 1800, 1906
39, Iceland, 1800,
39, Eire, 1800, 1880
39, Arctic/Longyearbyen, 1800, 1940
39, Arctic/Longyearbyen, 1945, 1980
39, Chile/EasterIsland, 2022, 2022
39, Pacific/Yap, 1800,
39, Atlantic/Jan_Mayen, 1800, 1940
39, Atlantic/Jan_Mayen, 1945, 1980

Timezones added:
Europe/Kyiv

------ End of updates in Content version 39 ----

Current Structure version: 3
Current Content Version  :38

Content Version 38
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
38, America/Santiago, 1800, 1927
38, Asia/Gaza, 2022,
38, Asia/Hebron, 2022,
38, America/Punta_Arenas, 1890, 1927
38, Europe/Kiev, 1992, 1996
38, Europe/Uzhgorod, 1992, 1996
38, Europe/Zaporozhye, 1992, 1996
38, Europe/Simferopol, 1992, 1994
38, Chile/Continental, 1800, 1927

------ End of updates in Content version 38 ----
Current Structure version: 3
Current Content Version  :37

Content Version 37
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
37, Africa/Accra, 1800,
37, America/Anguilla, 1800,
37, America/Antigua, 1800,
37, America/Nassau, 1800, 1964
37, America/Barbados, 1911, 1977
37, America/Dominica, 1800,
37, America/Grenada, 1800,
37, America/Guadeloupe, 1800,
37, America/Montserrat, 1800,
37, America/St_Kitts, 1800,
37, America/St_Lucia, 1800,
37, America/St_Vincent, 1800,
37, America/Tortola, 1800,
37, America/St_Thomas, 1800,
37, America/Aruba, 1800,
37, America/Curacao, 1800,
37, America/Guyana, 1800,
37, America/Port_of_Spain, 1800,
37, America/Atikokan, 1800,
37, America/Blanc-Sablon, 1800,
37, Antarctica/DumontDUrville, 1800,
37, Antarctica/Syowa, 1800,
37, Asia/Amman, 2022,
37, Asia/Gaza, 2021,
37, Africa/Juba, 2021,
37, America/Lower_Princes, 1800,
37, America/Kralendijk, 1800,
37, Asia/Hebron, 2021,
37, America/Creston, 1800,
37, Atlantic/Azores, 1950, 1951
37, Atlantic/Madeira, 1950, 1951
37, Europe/Lisbon, 1950, 1951
37, Pacific/Rarotonga, 1800, 1978
37, Pacific/Fiji, 2021, 2022
37, Pacific/Enderbury, 1800,
37, Pacific/Niue, 1901,
37, Pacific/Apia, 2021,
37, Pacific/Tongatapu, 1800, 1999
37, America/Marigot, 1800,
37, America/Virgin, 1800,
37, America/Coral_Harbour, 1800,
37, Portugal, 1950, 1951
37, America/St_Barthelemy, 1800,

Timezones added:
Pacific/Kanton

------ End of updates in Content version 37 ----

Current Structure version: 3
Current Content Version  :36

Content Version 36
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
36, Africa/Algiers, 1891, 1891
36, Africa/Luanda, 1800,
36, Africa/Porto-Novo, 1800,
36, Africa/Douala, 1800,
36, Africa/Bangui, 1800,
36, Africa/Kinshasa, 1800,
36, Africa/Brazzaville, 1800,
36, Africa/Djibouti, 1908,
36, Africa/Malabo, 1800,
36, Africa/Asmara, 1908,
36, Africa/Addis_Ababa, 1908,
36, Africa/Libreville, 1800,
36, Africa/Accra, 1915,
36, Africa/Nairobi, 1908,
36, Africa/Casablanca, 2023, 2023
36, Africa/Casablanca, 2031, 2031
36, Africa/Casablanca, 2038, 2038
36, Africa/Casablanca, 2046, 2046
36, Africa/Casablanca, 2054, 2054
36, Africa/Casablanca, 2062, 2062
36, Africa/Casablanca, 2069, 2069
36, Africa/Casablanca, 2077, 2077
36, Africa/El_Aaiun, 2023, 2023
36, Africa/El_Aaiun, 2031, 2031
36, Africa/El_Aaiun, 2038, 2038
36, Africa/El_Aaiun, 2046, 2046
36, Africa/El_Aaiun, 2054, 2054
36, Africa/El_Aaiun, 2062, 2062
36, Africa/El_Aaiun, 2069, 2069
36, Africa/El_Aaiun, 2077, 2077
36, Africa/Niamey, 1800,
36, Africa/Lagos, 1800,
36, Africa/Mogadishu, 1908,
36, Africa/Dar_es_Salaam, 1908,
36, Africa/Kampala, 1908,
36, Antarctica/Macquarie, 1917, 1917
36, Antarctica/Macquarie, 2010,
36, America/Whitehorse, 2020,
36, America/Dawson, 2020,
36, America/Nassau, 1942, 1964
36, America/Belize, 1942, 1973
36, America/Grand_Turk, 2015, 2018
36, Antarctica/Casey, 2018,
36, Asia/Jerusalem, 1940, 1957
36, Asia/Jerusalem, 1980, 1985
36, Asia/Gaza, 1940, 1946
36, Asia/Gaza, 1980, 1985
36, Asia/Gaza, 2015, 2015
36, Asia/Gaza, 2019,
36, Asia/Hebron, 1940, 1946
36, Asia/Hebron, 1980, 1985
36, Asia/Hebron, 2015, 2015
36, Asia/Hebron, 2019,
36, Atlantic/Bermuda, 1890, 1974
36, Australia/Darwin, 1916,
36, Australia/Perth, 1916, 1943
36, Australia/Brisbane, 1916, 1944
36, Australia/Lindeman, 1916, 1944
36, Australia/Adelaide, 1916, 1944
36, Australia/Hobart, 1917, 1944
36, Australia/Melbourne, 1916, 1944
36, Australia/Sydney, 1916, 1944
36, Australia/Broken_Hill, 1916, 1944
36, Australia/Currie, 1800, 1971
36, Australia/Eucla, 1916, 1943
36, Europe/Paris, 1891, 1911
36, Europe/Budapest, 1890, 1890
36, Europe/Budapest, 1918, 1941
36, Europe/Budapest, 1945, 1946
36, Europe/Budapest, 1950, 1983
36, Europe/Monaco, 1891, 1911
36, Europe/Volgograd, 2020,
36, Indian/Antananarivo, 1908,
36, Indian/Comoro, 1908,
36, Indian/Mahe, 1906,
36, Indian/Mayotte, 1908,
36, Pacific/Fiji, 2020, 2020
36, Pacific/Efate, 1973, 1984
36, Africa/Asmera, 1908,
36, Canada/Yukon, 2020,
36, Asia/Tel_Aviv, 1940, 1957
36, Asia/Tel_Aviv, 1980, 1985
36, Australia/North, 1916,
36, Australia/West, 1916, 1943
36, Australia/Queensland, 1916, 1944
36, Australia/South, 1916, 1944
36, Australia/Tasmania, 1917, 1944
36, Australia/Victoria, 1916, 1944
36, Australia/ACT, 1916, 1944
36, Australia/Yancowinna, 1916, 1944
36, Israel, 1940, 1957
36, Israel, 1980, 1985
36, Australia/Canberra, 1916, 1944
36, Australia/NSW, 1916, 1944

------ End of updates in Content version 36 ----


Current Structure version: 3
Current Content Version  :35

Content Version 35
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
35, Africa/Casablanca, 2020, 2020
35, Africa/Casablanca, 2028, 2028
35, Africa/Casablanca, 2035, 2035
35, Africa/Casablanca, 2043, 2043
35, Africa/Casablanca, 2051, 2051
35, Africa/Casablanca, 2059, 2059
35, Africa/Casablanca, 2064, 2064
35, Africa/Casablanca, 2066, 2066
35, Africa/Casablanca, 2071, 2071
35, Africa/Casablanca, 2074, 2074
35, Africa/Casablanca, 2079,
35, Africa/El_Aaiun, 2020, 2020
35, Africa/El_Aaiun, 2028, 2028
35, Africa/El_Aaiun, 2035, 2035
35, Africa/El_Aaiun, 2043, 2043
35, Africa/El_Aaiun, 2051, 2051
35, Africa/El_Aaiun, 2059, 2059
35, Africa/El_Aaiun, 2064, 2064
35, Africa/El_Aaiun, 2066, 2066
35, Africa/El_Aaiun, 2071, 2071
35, Africa/El_Aaiun, 2074, 2074
35, Africa/El_Aaiun, 2079,
35, America/Indiana/Tell_City, 1946, 1955
35, America/Indiana/Tell_City, 1960, 1961
35, America/Indiana/Tell_City, 1967, 1969
35, America/Louisville, 1946, 1950
35, America/Detroit, 1967, 1973
35, America/Edmonton, 1967, 1972
35, America/Vancouver, 1946, 1946
35, America/Whitehorse, 2020,
35, America/Dawson, 2020,
35, Asia/Harbin, 1919, 1940
35, Asia/Shanghai, 1919, 1940
35, Asia/Chungking, 1919, 1940
35, Asia/Hong_Kong, 1941, 1941
35, Asia/Tokyo, 1948,
35, Asia/Seoul, 1948, 1954
35, Europe/Vienna, 1946, 1946
35, Europe/Brussels, 1892, 1892
35, Europe/Kaliningrad, 1944, 1946
35, Europe/Istanbul, 1940, 1945
35, Europe/Istanbul, 1950, 1986
35, Pacific/Fiji, 2019,
35, Pacific/Norfolk, 1975,
35, America/Kentucky/Louisville, 1946, 1950
35, US/Michigan, 1967, 1973
35, Canada/Mountain, 1967, 1972
35, Canada/Pacific, 1946, 1946
35, Canada/Yukon, 2020,
35, PRC, 1919, 1940
35, Asia/Chongqing, 1919, 1940
35, Hongkong, 1941, 1941
35, Japan, 1948,
35, ROK, 1948, 1954
35, Turkey, 1940, 1945
35, Turkey, 1950, 1986
35, Asia/Istanbul, 1940, 1945
35, Asia/Istanbul, 1950, 1986

Timezones added:
America/Nuuk

------ End of updates in Content version 35 ----

Current Structure version: 3
Current Content Version  :34

Content Version 34
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
34, Africa/Casablanca, 2018,
34, Africa/El_Aaiun, 2018,
34, Africa/Sao_Tome, 2019,
34, America/Montreal, 1932, 1933
34, America/Sao_Paulo, 2019,
34, America/Cuiaba, 2019,
34, America/Toronto, 1932, 1933
34, America/Campo_Grande, 2019,
34, Pacific/Chuuk, 1800,
34, Pacific/Pohnpei, 1800,
34, Asia/Hong_Kong, 1904, 1952
34, Asia/Tehran, 2038, 2039
34, Asia/Tehran, 2042, 2043
34, Asia/Tehran, 2046, 2047
34, Asia/Tehran, 2050, 2051
34, Asia/Tehran, 2054, 2055
34, Asia/Tehran, 2058, 2059
34, Asia/Tehran, 2063, 2063
34, Asia/Tehran, 2067, 2067
34, Asia/Tehran, 2071, 2071
34, Asia/Tehran, 2075, 2075
34, Asia/Tehran, 2079,
34, Asia/Jerusalem, 1980, 1985
34, Asia/Jerusalem, 2006, 2012
34, Asia/Gaza, 1980, 1985
34, Asia/Gaza, 2019,
34, Asia/Qyzylorda, 2018,
34, America/Metlakatla, 2018, 2019
34, Asia/Hebron, 1980, 1985
34, Asia/Hebron, 2019,
34, Europe/Rome, 1866, 1866
34, Pacific/Guam, 1941,
34, Pacific/Saipan, 1941,
34, Pacific/Majuro, 1914,
34, Pacific/Kwajalein, 1936,
34, Pacific/Truk, 1800,
34, Pacific/Ponape, 1800,
34, Pacific/Kosrae, 1800,
34, Pacific/Nauru, 1942,
34, Pacific/Palau, 1800,
34, Canada/Eastern, 1932, 1933
34, Brazil/East, 2019,
34, Hongkong, 1904, 1952
34, Iran, 2038, 2039
34, Iran, 2042, 2043
34, Iran, 2046, 2047
34, Iran, 2050, 2051
34, Iran, 2054, 2055
34, Iran, 2058, 2059
34, Iran, 2063, 2063
34, Iran, 2067, 2067
34, Iran, 2071, 2071
34, Iran, 2075, 2075
34, Iran, 2079,
34, Asia/Tel_Aviv, 1980, 1985
34, Asia/Tel_Aviv, 2006, 2012
34, Europe/Vatican, 1866, 1866
34, Kwajalein, 1936,
34, Pacific/Yap, 1800,
34, Israel, 1980, 1985
34, Israel, 2006, 2012
34, Europe/San_Marino, 1866, 1866

Timezones added:
Asia/Qostanay

------ End of updates in Content version 34 ----

Current Structure version: 3
Current Content Version  :33

Content Version 33
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
33, Africa/Casablanca, 2018,
33, Africa/El_Aaiun, 2018,
33, America/Santiago, 2019,
33, Asia/Harbin, 1940,
33, Asia/Shanghai, 1940,
33, Asia/Chungking, 1940,
33, Asia/Macao, 1800, 1961
33, Asia/Macao, 1963, 1966
33, Asia/Macao, 1972, 1974
33, Asia/Macao, 1977,
33, Asia/Tokyo, 1948,
33, Asia/Pyongyang, 2018,
33, Europe/Volgograd, 2018,
33, Pacific/Honolulu, 1945,
33, Pacific/Easter, 2019,
33, Pacific/Fiji, 2019, 2019
33, Pacific/Fiji, 2030, 2030
33, Pacific/Fiji, 2036, 2036
33, Pacific/Johnston, 1945,
33, Chile/Continental, 2019,
33, PRC, 1940,
33, Asia/Chongqing, 1940,
33, Asia/Macau, 1800, 1961
33, Asia/Macau, 1963, 1966
33, Asia/Macau, 1972, 1974
33, Asia/Macau, 1977,
33, Japan, 1948,
33, US/Hawaii, 1945,
33, Chile/EasterIsland, 2019,

------ End of updates in Content version 33 ----

Current Structure version: 3
Current Content Version  :32

Content Version 32
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
32, Africa/Bissau, 1912,
32, Africa/Windhoek, 1994,
32, Africa/Sao_Tome, 1800,
32, America/Jamaica, 1800, 1912
32, America/Grand_Turk, 1890, 1912
32, America/Sao_Paulo, 2018,
32, America/Cuiaba, 2018,
32, America/Montevideo, 1800, 1923
32, America/Montevideo, 1936, 1936
32, America/Montevideo, 1939, 1939
32, America/Montevideo, 1942, 1959
32, America/Montevideo, 1966, 1990
32, America/Campo_Grande, 2018,
32, Antarctica/Casey, 2018,
32, Asia/Macao, 1911, 1911
32, Asia/Tokyo, 1948,
32, Asia/Pyongyang, 2018,
32, Asia/Gaza, 2018, 2019
32, Asia/Gaza, 2024, 2025
32, Asia/Gaza, 2029, 2031
32, Asia/Gaza, 2035, 2036
32, Asia/Gaza, 2040,
32, Asia/Hebron, 2018, 2019
32, Asia/Hebron, 2024, 2025
32, Asia/Hebron, 2029, 2031
32, Asia/Hebron, 2035, 2036
32, Asia/Hebron, 2040,
32, Atlantic/Azores, 1912, 1912
32, Atlantic/Madeira, 1912, 1912
32, Atlantic/Cape_Verde, 1907,
32, Europe/Dublin, 1971,
32, Europe/Prague, 1944, 1947
32, Europe/Lisbon, 1912, 1912
32, Pacific/Enderbury, 1994,
32, Pacific/Kiritimati, 1994,
32, Jamaica, 1800, 1912
32, Brazil/East, 2018,
32, Asia/Macau, 1911, 1911
32, Japan, 1948,
32, Eire, 1971,
32, Europe/Bratislava, 1944, 1947
32, Portugal, 1912, 1912

------ End of updates in Content version 32 ----


Current Structure version: 3
Current Content Version  :31

Content Version 31
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
31, Africa/Windhoek, 1994, 1994
31, Africa/Windhoek, 2017,
31, Africa/Khartoum, 2017,
31, America/Juneau, 1867, 1867
31, America/Yakutat, 1867, 1867
31, America/Anchorage, 1867, 1867
31, America/Nome, 1800, 1867
31, America/Adak, 1800, 1867
31, America/Detroit, 1967, 1973
31, America/Grand_Turk, 2018,
31, Asia/Rangoon, 1800,
31, Asia/Calcutta, 1854,
31, America/Sitka, 1867, 1867
31, America/Metlakatla, 1867, 1867
31, Africa/Juba, 1800, 1930
31, Asia/Yangon, 1800,
31, Asia/Famagusta, 2017,
31, Europe/Dublin, 1946, 1947
31, Pacific/Fiji, 2018, 2018
31, Pacific/Fiji, 2024, 2024
31, Pacific/Fiji, 2029, 2029
31, Pacific/Fiji, 2035, 2035
31, Pacific/Pago_Pago, 1879,
31, Pacific/Apia, 1879, 1892
31, Pacific/Tongatapu, 2017,
31, Pacific/Midway, 1879,
31, US/Alaska, 1867, 1867
31, America/Atka, 1800, 1867
31, US/Michigan, 1967, 1973
31, Asia/Kolkata, 1854,
31, Eire, 1946, 1947
31, US/Samoa, 1879,
31, US/Aleutian, 1800, 1867
31, Pacific/Samoa, 1879,

------ End of updates in Content version 31 ----

Current Structure version: 3
Current Content Version  :30

Content Version 30 
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
30, Africa/Monrovia, 1972,
30, Africa/Ceuta, 1901, 1928
30, America/Port-au-Prince, 2017,
30, America/Guayaquil, 1992,
30, America/Guyana, 1966,
30, America/Paramaribo, 1975,
30, Antarctica/Palmer, 2016,
30, Asia/Dacca, 1971,
30, Asia/Macao, 1999,
30, Asia/Dili, 1945,
30, Asia/Tokyo, 1895, 1948
30, Asia/Seoul, 1937, 1945
30, Asia/Pyongyang, 1937,
30, Asia/Kuching, 1981,
30, Asia/Hovd, 2017,
30, Asia/Ulaanbaatar, 2017,
30, Asia/Singapore, 1965,
30, Asia/Oral, 1924, 1930
30, Asia/Choibalsan, 2017,
30, Asia/Atyrau, 1924, 1930
30, Europe/Madrid, 1901, 1975
30, Europe/Madrid, 1978, 1978
30, Pacific/Galapagos, 1992,
30, Pacific/Pago_Pago, 1967,
30, Pacific/Midway, 1967,
30, Asia/Dhaka, 1971,
30, Asia/Macau, 1999,
30, Japan, 1895, 1948
30, ROK, 1937, 1945
30, Asia/Ulan_Bator, 2017,
30, Singapore, 1965,
30, US/Samoa, 1967,
30, Pacific/Samoa, 1967,
30, Africa/Monrovia, 1972,
30, Africa/Ceuta, 1901, 1928
30, America/Port-au-Prince, 2017,
30, America/Guayaquil, 1992,
30, America/Guyana, 1966,
30, America/Paramaribo, 1975,
30, Antarctica/Palmer, 2016,
30, Asia/Dacca, 1971,
30, Asia/Macao, 1999,
30, Asia/Dili, 1945,
30, Asia/Tokyo, 1895, 1948
30, Asia/Seoul, 1937, 1945
30, Asia/Pyongyang, 1937,
30, Asia/Kuching, 1981,
30, Asia/Hovd, 2017,
30, Asia/Ulaanbaatar, 2017,
30, Asia/Singapore, 1965,
30, Asia/Oral, 1924, 1930
30, Asia/Choibalsan, 2017,
30, Asia/Atyrau, 1924, 1930
30, Europe/Madrid, 1901, 1975
30, Europe/Madrid, 1978, 1978
30, Pacific/Galapagos, 1992,
30, Pacific/Pago_Pago, 1967,
30, Pacific/Midway, 1967,
30, Asia/Dhaka, 1971,
30, Asia/Macau, 1999,
30, Japan, 1895, 1948
30, ROK, 1937, 1945
30, Asia/Ulan_Bator, 2017,
30, Singapore, 1965,
30, US/Samoa, 1967,
30, Pacific/Samoa, 1967,

Timezones added:
America/Punta_Arenas

------ End of updates in Content version 30 ----

Current Structure version: 3
Current Content Version  :29

Content Version 29
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
 29, Antarctica/Casey, 2016,
 29, Asia/Gaza, 2016,
 29, Asia/Hebron, 2016,
 29, Europe/Rome, 1893, 1920
 29, Europe/Rome, 1944, 1944
 29, Europe/Rome, 1967, 1974
 29, Europe/Malta, 1916, 1920
 29, Europe/Malta, 1944, 1944
 29, Europe/Malta, 1967, 1972
 29, Europe/Istanbul, 1986, 1990
 29, Europe/Istanbul, 1994, 1994
 29, Pacific/Tongatapu, 2016,
 29, Europe/Vatican, 1893, 1920
 29, Europe/Vatican, 1944, 1944
 29, Europe/Vatican, 1967, 1974
 29, Turkey, 1986, 1990
 29, Turkey, 1994, 1994
 29, Europe/San_Marino, 1893, 1920
 29, Europe/San_Marino, 1944, 1944
 29, Europe/San_Marino, 1967, 1974
 29, Asia/Istanbul, 1986, 1990
 29, Asia/Istanbul, 1994, 1994

Timezones added:
Asia/Famagusta
Asia/Atyrau
Europe/Saratov

------ End of updates in Content version 29 ----

Current Structure version: 3
Current Content Version  :28

Content Version 28
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
28, America/Santa_Isabel, 1954, 1960
28, America/Los_Angeles, 1948, 1966
28, America/Tijuana, 1954, 1960
28, Asia/Yerevan, 1991, 1991
28, Asia/Baku, 1991, 1991
28, Asia/Tbilisi, 1991, 1991
28, Asia/Ashgabat, 1991,
28, Asia/Samarkand, 1991,
28, Asia/Tashkent, 1991,
28, Asia/Sakhalin, 1937, 1945
28, Europe/Kirov, 1919, 1919
28, Europe/Ulyanovsk, 1919, 1919
28, Europe/Minsk, 2014,
28, Europe/Moscow, 1919, 1919
28, Europe/Samara, 1919, 1981
28, Europe/Istanbul, 2016,
28, Europe/Volgograd, 1925, 1981
28, US/Pacific, 1948, 1966
28, America/Ensenada, 1954, 1960
28, Asia/Ashkhabad, 1991,
28, W-SU, 1919, 1919
28, Turkey, 2016,
28, Mexico/BajaNorte, 1954, 1960
28, Asia/Istanbul, 2016,
28, US/Pacific-New, 1948, 1966
28, PST, 1948, 1966

------ End of updates in Content version 28 ----

Current Structure version: 3
Current Content Version  :27

Content Version 27
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
27, Asia/Novokuznetsk, 2014,
27, Asia/Baku, 1992, 1992
27, Asia/Novosibirsk, 2016,
27, Europe/Minsk, 1992, 1992

------ End of updates in Content version 27 ----

Current Structure version: 3
Current Content Version  :26

Content Version 26
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
26, Asia/Novokuznetsk, 1992, 1992
26, America/Santa_Isabel, 1800, 1800
26, America/Santa_Isabel, 2010,
26, America/Cayman, 1800,
26, America/Port-au-Prince, 2016,
26, America/Santiago, 2015,
26, America/Caracas, 2016,
26, Antarctica/Palmer, 2015,
26, Asia/Yerevan, 1992, 1992
26, Asia/Baku, 1992, 1992
26, Asia/Baku, 2016,
26, Asia/Tehran, 2038,
26, Asia/Almaty, 1991, 1993
26, Asia/Aqtobe, 1991, 1993
26, Asia/Aqtau, 1962, 1981
26, Asia/Aqtau, 1991, 1995
26, Asia/Aqtau, 2004,
26, Asia/Karachi, 2002, 2002
26, Asia/Gaza, 2016,
26, Asia/Yekaterinburg, 1992, 1992
26, Asia/Omsk, 1992, 1992
26, Asia/Novosibirsk, 1992, 1992
26, Asia/Krasnoyarsk, 1992, 1992
26, Asia/Irkutsk, 1992, 1992
26, Asia/Yakutsk, 1992, 1992
26, Asia/Vladivostok, 1992, 1992
26, Asia/Magadan, 1992, 1992
26, Asia/Magadan, 2016,
26, Asia/Kamchatka, 1992, 1992
26, Asia/Anadyr, 1992, 1992
26, Asia/Qyzylorda, 1991,
26, Asia/Oral, 1991, 1993
26, Asia/Oral, 2004,
26, Asia/Sakhalin, 1992, 1992
26, Asia/Sakhalin, 2016,
26, America/Metlakatla, 2015,
26, Asia/Hebron, 2016,
26, Asia/Khandyga, 1992, 1992
26, Asia/Ust-Nera, 1992, 1992
26, Asia/Chita, 1992, 1992
26, Asia/Chita, 2016,
26, Asia/Srednekolymsk, 1992, 1992
26, Europe/Minsk, 1992, 1992
26, Europe/Vilnius, 1989, 1991
26, Europe/Chisinau, 1990, 1991
26, Europe/Kaliningrad, 1989, 1992
26, Europe/Moscow, 1992, 1992
26, Europe/Samara, 1992, 1992
26, Europe/Volgograd, 1988, 1989
26, Europe/Volgograd, 1992, 1992
26, Pacific/Easter, 2015,
26, Chile/Continental, 2015,
26, Iran, 2038,
26, Europe/Tiraspol, 1990, 1991
26, W-SU, 1992, 1992
26, Chile/EasterIsland, 2015,

Timezones added:
Asia/Barnaul
Asia/Tomsk
Europe/Astrakhan
Europe/Kirov
Europe/Ulyanovsk

------ End of updates in Content version 26 ----


Current Structure version: 3
Current Content Version  :25

Content Version 25
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
25, Africa/Casablanca, 2015, 2025
25, Africa/Casablanca, 2035, 2037
25, Africa/El_Aaiun, 2015, 2025
25, Africa/El_Aaiun, 2035, 2037
25, America/Whitehorse, 1966, 1967
25, America/Cayman, 1800,
25, America/Montevideo, 2015,
25, Asia/Pyongyang, 2015,
25, Europe/Chisinau, 1997,
25, Europe/Istanbul, 2015, 2015
25, Pacific/Fiji, 2016, 2017
25, Pacific/Fiji, 2021, 2023
25, Pacific/Fiji, 2027, 2028
25, Pacific/Fiji, 2033, 2034
25, Pacific/Fiji, 2038,
25, Pacific/Norfolk, 1974,
25, Canada/Yukon, 1966, 1967
25, Europe/Tiraspol, 1997,
25, Turkey, 2015, 2015
25, Asia/Istanbul, 2015, 2015
25, Africa/Casablanca, 2015, 2025
25, Africa/Casablanca, 2035, 2037
25, Africa/El_Aaiun, 2015, 2025
25, Africa/El_Aaiun, 2035, 2037
25, America/Whitehorse, 1966, 1967
25, America/Cayman, 1800,
25, America/Montevideo, 2015,
25, Asia/Pyongyang, 2015,
25, Europe/Chisinau, 1997,
25, Europe/Istanbul, 2015, 2015
25, Pacific/Fiji, 2016, 2017
25, Pacific/Fiji, 2021, 2023
25, Pacific/Fiji, 2027, 2028
25, Pacific/Fiji, 2033, 2034
25, Pacific/Fiji, 2038,
25, Pacific/Norfolk, 1974,
25, Canada/Yukon, 1966, 1967
25, Europe/Tiraspol, 1997,
25, Turkey, 2015, 2015
25, Asia/Istanbul, 2015, 2015

Timezones added:

America/Fort_Nelson

------ End of updates in Content version 25 ----

Current Structure version: 3
Current Content Version  :24

Content Version 24
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
24, Africa/Luanda, 1800,
24, Africa/Porto-Novo, 1800,
24, Africa/Gaborone, 1800,
24, Africa/Bujumbura, 1800,
24, Africa/Douala, 1800,
24, Africa/Bangui, 1800,
24, Africa/Kinshasa, 1800,
24, Africa/Lubumbashi, 1800,
24, Africa/Brazzaville, 1800,
24, Africa/Djibouti, 1800,
24, Africa/Cairo, 2015,
24, Africa/Malabo, 1800,
24, Africa/Asmara, 1800,
24, Africa/Addis_Ababa, 1800,
24, Africa/Libreville, 1800,
24, Africa/Bissau, 1911,
24, Africa/Maseru, 1800,
24, Africa/Blantyre, 1800,
24, Africa/Niamey, 1800,
24, Africa/Kigali, 1800,
24, Africa/Mogadishu, 1800,
24, Africa/Mbabane, 1800,
24, Africa/Dar_es_Salaam, 1800,
24, Africa/Kampala, 1800,
24, Africa/Lusaka, 1800,
24, Africa/Harare, 1800,
24, Asia/Novokuznetsk, 1920, 1924
24, America/Montreal, 1800, 1940
24, America/Montreal, 1947, 1950
24, America/Cancun, 2015,
24, America/Antigua, 1800,
24, America/Cayman, 1800,
24, America/Jamaica, 1974, 1974
24, America/Grand_Turk, 2015,
24, America/Santiago, 1910, 1918
24, America/Santiago, 1932, 1947
24, America/Santiago, 1988, 1990
24, America/Santiago, 2015,
24, Antarctica/Palmer, 1988, 1990
24, Antarctica/Palmer, 2015,
24, Asia/Bahrain, 1800,
24, Asia/Dacca, 2009,
24, Asia/Phnom_Penh, 1800,
24, Asia/Tbilisi, 1800, 1924
24, Asia/Seoul, 1889,
24, Asia/Pyongyang, 1889,
24, Asia/Kuwait, 1800,
24, Asia/Vientiane, 1800,
24, Asia/Hovd, 2015,
24, Asia/Ulaanbaatar, 2015,
24, Asia/Muscat, 1800,
24, Asia/Gaza, 2014,
24, Asia/Samarkand, 1800, 1924
24, Asia/Saigon, 1906,
24, Asia/Aden, 1800,
24, Asia/Yekaterinburg, 1916, 1930
24, Asia/Omsk, 1800, 1919
24, Asia/Krasnoyarsk, 1800, 1920
24, Asia/Irkutsk, 1800, 1920
24, Asia/Yakutsk, 1800, 1919
24, Asia/Vladivostok, 1800, 1922
24, Asia/Choibalsan, 2015,
24, Asia/Hebron, 2014,
24, Atlantic/Reykjavik, 1800, 1908
24, Atlantic/Reykjavik, 1919, 1939
24, Atlantic/Azores, 1911, 1912
24, Atlantic/Madeira, 1911, 1912
24, Europe/Minsk, 2014,
24, Europe/Riga, 1800, 1926
24, Europe/Lisbon, 1800, 1912
24, Europe/Samara, 1800, 1919
24, Indian/Antananarivo, 1800,
24, Indian/Comoro, 1800,
24, Indian/Mayotte, 1800,
24, Pacific/Easter, 1800, 1968
24, Pacific/Easter, 1988, 1990
24, Pacific/Easter, 2015,
24, Pacific/Fiji, 2014,
24, Pacific/Saipan, 1800,
24, Pacific/Midway, 1800,
24, Egypt, 2015,
24, Africa/Asmera, 1800,
24, Canada/Eastern, 1800, 1940
24, Canada/Eastern, 1947, 1950
24, Jamaica, 1974, 1974
24, Chile/Continental, 1910, 1918
24, Chile/Continental, 1932, 1947
24, Chile/Continental, 1988, 1990
24, Chile/Continental, 2015,
24, Asia/Dhaka, 2009,
24, ROK, 1889,
24, Asia/Ulan_Bator, 2015,
24, Asia/Ho_Chi_Minh, 1906,
24, Iceland, 1800, 1908
24, Iceland, 1919, 1939
24, Portugal, 1800, 1912
24, Chile/EasterIsland, 1800, 1968
24, Chile/EasterIsland, 1988, 1990
24, Chile/EasterIsland, 2015,
24, Africa/Luanda, 1800,
24, Africa/Porto-Novo, 1800,
24, Africa/Gaborone, 1800,
24, Africa/Bujumbura, 1800,
24, Africa/Douala, 1800,
24, Africa/Bangui, 1800,
24, Africa/Kinshasa, 1800,
24, Africa/Lubumbashi, 1800,
24, Africa/Brazzaville, 1800,
24, Africa/Djibouti, 1800,
24, Africa/Cairo, 2015,
24, Africa/Malabo, 1800,
24, Africa/Asmara, 1800,
24, Africa/Addis_Ababa, 1800,
24, Africa/Libreville, 1800,
24, Africa/Bissau, 1911,
24, Africa/Maseru, 1800,
24, Africa/Blantyre, 1800,
24, Africa/Niamey, 1800,
24, Africa/Kigali, 1800,
24, Africa/Mogadishu, 1800,
24, Africa/Mbabane, 1800,
24, Africa/Dar_es_Salaam, 1800,
24, Africa/Kampala, 1800,
24, Africa/Lusaka, 1800,
24, Africa/Harare, 1800,
24, Asia/Novokuznetsk, 1920, 1924
24, America/Montreal, 1800, 1940
24, America/Montreal, 1947, 1950
24, America/Cancun, 2015,
24, America/Antigua, 1800,
24, America/Cayman, 1800,
24, America/Jamaica, 1974, 1974
24, America/Grand_Turk, 2015,
24, America/Santiago, 1910, 1918
24, America/Santiago, 1932, 1947
24, America/Santiago, 1988, 1990
24, America/Santiago, 2015,
24, Antarctica/Palmer, 1988, 1990
24, Antarctica/Palmer, 2015,
24, Asia/Bahrain, 1800,
24, Asia/Dacca, 2009,
24, Asia/Phnom_Penh, 1800,
24, Asia/Tbilisi, 1800, 1924
24, Asia/Seoul, 1889,
24, Asia/Pyongyang, 1889,
24, Asia/Kuwait, 1800,
24, Asia/Vientiane, 1800,
24, Asia/Hovd, 2015,
24, Asia/Ulaanbaatar, 2015,
24, Asia/Muscat, 1800,
24, Asia/Gaza, 2014,
24, Asia/Samarkand, 1800, 1924
24, Asia/Saigon, 1906,
24, Asia/Aden, 1800,
24, Asia/Yekaterinburg, 1916, 1930
24, Asia/Omsk, 1800, 1919
24, Asia/Krasnoyarsk, 1800, 1920
24, Asia/Irkutsk, 1800, 1920
24, Asia/Yakutsk, 1800, 1919
24, Asia/Vladivostok, 1800, 1922
24, Asia/Choibalsan, 2015,
24, Asia/Hebron, 2014,
24, Atlantic/Reykjavik, 1800, 1908
24, Atlantic/Reykjavik, 1919, 1939
24, Atlantic/Azores, 1911, 1912
24, Atlantic/Madeira, 1911, 1912
24, Europe/Minsk, 2014,
24, Europe/Riga, 1800, 1926
24, Europe/Lisbon, 1800, 1912
24, Europe/Samara, 1800, 1919
24, Indian/Antananarivo, 1800,
24, Indian/Comoro, 1800,
24, Indian/Mayotte, 1800,
24, Pacific/Easter, 1800, 1968
24, Pacific/Easter, 1988, 1990
24, Pacific/Easter, 2015,
24, Pacific/Fiji, 2014,
24, Pacific/Saipan, 1800,
24, Pacific/Midway, 1800,
24, Egypt, 2015,
24, Africa/Asmera, 1800,
24, Canada/Eastern, 1800, 1940
24, Canada/Eastern, 1947, 1950
24, Jamaica, 1974, 1974
24, Chile/Continental, 1910, 1918
24, Chile/Continental, 1932, 1947
24, Chile/Continental, 1988, 1990
24, Chile/Continental, 2015,
24, Asia/Dhaka, 2009,
24, ROK, 1889,
24, Asia/Ulan_Bator, 2015,
24, Asia/Ho_Chi_Minh, 1906,
24, Iceland, 1800, 1908
24, Iceland, 1919, 1939
24, Portugal, 1800, 1912
24, Chile/EasterIsland, 1800, 1968
24, Chile/EasterIsland, 1988, 1990
24, Chile/EasterIsland, 2015,

Timezones added:
Pacific/Bougainville

------ End of updates in Content version 24 ----

Current Structure version: 3
Current Content Version  :23

Content Version 23
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
23, Africa/Ouagadougou, 1800,
23, Africa/Cairo, 2014, 2022
23, Africa/Banjul, 1800,
23, Africa/Accra, 1920, 1936
23, Africa/Conakry, 1800,
23, Africa/Bamako, 1800,
23, Africa/Nouakchott, 1800,
23, Africa/Casablanca, 2014, 2025
23, Africa/Casablanca, 2035, 2038
23, Africa/El_Aaiun, 2014, 2025
23, Africa/El_Aaiun, 2035, 2038
23, Africa/Sao_Tome, 1800,
23, Africa/Dakar, 1800,
23, Africa/Freetown, 1800,
23, Africa/Lome, 1800,
23, Asia/Novokuznetsk, 2014,
23, Asia/Harbin, 1800, 1986
23, Asia/Shanghai, 1800, 1927
23, Asia/Chungking, 1800, 1980
23, Asia/Urumqi, 1980,
23, Asia/Kashgar, 1800,
23, Asia/Taipei, 1937, 1947
23, Asia/Taipei, 1979,
23, Asia/Tbilisi, 1800, 1924
23, Asia/Tokyo, 1937, 1937
23, Asia/Seoul, 1937, 1954
23, Asia/Pyongyang, 1937,
23, Asia/Riyadh, 1947,
23, Asia/Tashkent, 1800, 1924
23, Asia/Yekaterinburg, 1800, 1919
23, Asia/Yekaterinburg, 2014,
23, Asia/Omsk, 2014,
23, Asia/Novosibirsk, 2014,
23, Asia/Krasnoyarsk, 2014,
23, Asia/Irkutsk, 1800, 1920
23, Asia/Irkutsk, 2014,
23, Asia/Yakutsk, 2014,
23, Asia/Vladivostok, 1800, 1922
23, Asia/Vladivostok, 2014,
23, Asia/Magadan, 2014,
23, Asia/Sakhalin, 1937, 1937
23, Asia/Sakhalin, 2014,
23, Atlantic/St_Helena, 1800,
23, Europe/Helsinki, 1800, 1942
23, Europe/Budapest, 1918, 1941
23, Europe/Budapest, 1945, 1945
23, Europe/Riga, 1800, 1926
23, Europe/Kaliningrad, 2014,
23, Europe/Moscow, 1800, 1919
23, Europe/Moscow, 2014,
23, Europe/Simferopol, 2014,
23, Europe/Volgograd, 2014,
23, Pacific/Chatham, 1868, 1956
23, Pacific/Pago_Pago, 1911,
23, Egypt, 2014, 2022
23, Africa/Timbuktu, 1800,
23, PRC, 1800, 1927
23, Asia/Chongqing, 1800, 1980
23, ROC, 1937, 1947
23, ROC, 1979,
23, Japan, 1937, 1937
23, ROK, 1937, 1954
23, Europe/Mariehamn, 1800, 1942
23, W-SU, 1800, 1919
23, W-SU, 2014,
23, NZ-CHAT, 1868, 1956
23, US/Samoa, 1911,
23, Pacific/Samoa, 1911, 
 
Timezones added:
Asia/Srednekolymsk
Asia/Chita
Asia/Khandyga
Asia/Ust-Nera

------ End of updates in Content version 23 ----

Current Structure version: 3
Current Content Version  :22


Content Version 22
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
22, Africa/Cairo, 2014,
22, Africa/Tripoli, 2013,
22, Africa/Casablanca, 2013,
22, Africa/El_Aaiun, 1976,
22, America/Havana, 2004, 2004
22, America/Araguaina, 2013,
22, America/Porto_Acre, 2013,
22, America/Eirunepe, 2013,
22, Asia/Jerusalem, 1988, 1988
22, Asia/Amman, 2013, 2013
22, Asia/Gaza, 1988, 1988
22, Asia/Gaza, 2013,
22, Asia/Hebron, 1988, 1988
22, Asia/Hebron, 2013,
22, Europe/Istanbul, 2014, 2014
22, Europe/Kiev, 1990, 1992
22, Europe/Simferopol, 2014,
22, Pacific/Fiji, 2014,
22, Egypt, 2014,
22, Libya, 2013,
22, Cuba, 2004, 2004
22, Brazil/Acre, 2013,
22, Asia/Tel_Aviv, 1988, 1988
22, Turkey, 2014, 2014
22, America/Rio_Branco, 2013,
22, Israel, 1988, 1988
22, Asia/Istanbul, 2014, 2014
 
Timezones added:
Antarctica/Troll

------ End of updates in Content version 22 ----

Current Structure version: 3
Current Content Version  :21

Content Version 21
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
21, Africa/Casablanca, 2013, 2013
21, America/Argentina/San_Luis, 2009,
21, America/Anguilla, 1800,
21, America/Cayman, 1890,
21, America/Dominica, 1800,
21, America/Grenada, 1800,
21, America/Guadeloupe, 1800,
21, America/Jamaica, 1800, 1912
21, America/Montserrat, 1800,
21, America/St_Kitts, 1800,
21, America/St_Lucia, 1800,
21, America/St_Vincent, 1800,
21, America/Grand_Turk, 1890, 1912
21, America/Tortola, 1800,
21, America/St_Thomas, 1800,
21, America/Aruba, 1800,
21, Antarctica/McMurdo, 1800, 1956
21, Asia/Jerusalem, 1800, 1879
21, Asia/Jerusalem, 2013,
21, Africa/Juba, 1800, 1930
21, Europe/Busingen, 1848, 1894
21, Europe/Vaduz, 1800, 1981
21, Europe/Zurich, 1848, 1894
21, Pacific/Fiji, 2013, 2015
21, Pacific/Fiji, 2019, 2020
21, Pacific/Fiji, 2024, 2026
21, Pacific/Fiji, 2030, 2031
21, Pacific/Fiji, 2036, 2037
21, Pacific/Johnston, 1800,
21, America/Marigot, 1800,
21, Jamaica, 1800, 1912
21, America/Virgin, 1800,
21, Antarctica/South_Pole, 1800, 1956
21, Asia/Tel_Aviv, 1800, 1879
21, Asia/Tel_Aviv, 2013,
21, America/St_Barthelemy, 1800,
21, Israel, 1800, 1879
21, Israel, 2013,

Timezones added:
no new zones are added
------ End of updates in Content version 21 ----

Current Structure version: 3
Current Content Version  :20

Content Version 20
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
20, Africa/Gaborone, 1884,
20, Africa/Cairo, 1800, 1900
20, Africa/Casablanca, 2013, 2022
20, Antarctica/Macquarie, 1899, 1948
20, America/Nassau, 1800, 1912
20, America/Barbados, 1800, 1932
20, America/Costa_Rica, 1800, 1921
20, America/Port-au-Prince, 2013,
20, America/Santiago, 2013,
20, America/Bogota, 1800,
20, America/Curacao, 1800,
20, America/Asuncion, 2013,
20, Antarctica/Palmer, 2013,
20, Asia/Rangoon, 1879,
20, Asia/Shanghai, 1800, 1927
20, Asia/Hong_Kong, 1800, 1904
20, Asia/Muscat, 1800,
20, Asia/Gaza, 2008,
20, Asia/Aden, 1800,
20, America/Lower_Princes, 1800,
20, America/Kralendijk, 1800,
20, Asia/Hebron, 2008,
20, Atlantic/Bermuda, 1800, 1930
20, Europe/Vienna, 1800, 1893
20, Pacific/Easter, 2013,
20, Pacific/Fiji, 1800, 1915
20, Egypt, 1800, 1900
20, Chile/Continental, 2013,
20, PRC, 1800, 1927
20, Hongkong, 1800, 1904
20, Chile/EasterIsland, 2013,

Timezones added:
no new zones are added
------ End of updates in Content version 20 ----


Current Structure version: 3
Current Content Version  :19

Content Version 19
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
19, Africa/Tripoli, 2012,
19, Africa/Casablanca, 2012, 2012
19, America/Bahia, 2012,
19, America/Havana, 2012,
19, America/Araguaina, 2012,
19, Asia/Jerusalem, 2013,
19, Asia/Amman, 2012, 2013
19, Asia/Gaza, 2012,
19, Asia/Hebron, 2012,
19, Pacific/Fiji, 2012,
19, Pacific/Apia, 2012,
19, Pacific/Fakaofo, 1901,
19, Libya, 2012,
19, Cuba, 2012,
19, Asia/Tel_Aviv, 2013,
19, Israel, 2013,

Timezones added:
no new zones are added
------ End of updates in Content version 19 ----


Current Structure version: 3
Current Content Version  :18

Content Version 18
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
18, Africa/Casablanca, 2012,
18, America/Bahia, 2011,
18, America/Moncton, 1918, 1918
18, America/St_Johns, 1918, 1918
18, America/Goose_Bay, 1918, 1918
18, America/Halifax, 1918, 1918
18, America/Glace_Bay, 1918, 1918
18, America/Montreal, 1918, 1918
18, America/Nipigon, 1918, 1918
18, America/Rainy_River, 1918, 1918
18, America/Winnipeg, 1918, 1918
18, America/Regina, 1918, 1918
18, America/Swift_Current, 1918, 1918
18, America/Edmonton, 1918, 1918
18, America/Vancouver, 1918, 1918
18, America/Dawson_Creek, 1918, 1918
18, America/Havana, 2011, 2012
18, America/Port-au-Prince, 2012,
18, America/Santiago, 2012, 2012
18, America/Toronto, 1918, 1918
18, America/Atikokan, 1918, 1918
18, America/Blanc-Sablon, 1918,
18, Antarctica/Casey, 2011,
18, Antarctica/Davis, 2011,
18, Antarctica/Palmer, 2008, 2012
18, Asia/Yerevan, 2012,
18, Asia/Gaza, 2008, 2008
18, Asia/Gaza, 2011,
18, Asia/Damascus, 2012,
18, America/Sitka, 1800, 1867
18, Atlantic/Stanley, 2010,
18, Europe/Minsk, 2011,
18, Pacific/Easter, 2012, 2012
18, Pacific/Fiji, 2011,
18, Pacific/Fakaofo, 2011,
18, Canada/Newfoundland, 1918, 1918
18, Canada/Atlantic, 1918, 1918
18, Canada/Eastern, 1918, 1918
18, Canada/Central, 1918, 1918
18, Canada/East-Saskatchewan, 1918, 1918
18, Canada/Mountain, 1918, 1918
18, Canada/Pacific, 1918, 1918
18, Cuba, 2011, 2012
18, Chile/Continental, 2012, 2012
18, America/Coral_Harbour, 1918, 1918
18, Chile/EasterIsland, 2012, 2012
18, Canada/Saskatchewan, 1918, 1918

Timezones added:
America/Creston
Asia/Hebron

------ End of updates in Content version 18 ----


Current Structure version: 3
Current Content Version  :17

Content Version 17
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
17, Africa/Nairobi, 1939,
17, Africa/Dar_es_Salaam, 1947,
17, Africa/Kampala, 1947,
17, America/St_Johns, 2011,
17, America/Goose_Bay, 2011,
17, America/Resolute, 2007,
17, Asia/Yekaterinburg, 2011,
17, Asia/Omsk, 2011,
17, Asia/Novosibirsk, 2011,
17, Asia/Krasnoyarsk, 2011,
17, Asia/Irkutsk, 2011,
17, Asia/Yakutsk, 2011,
17, Asia/Vladivostok, 2011,
17, Asia/Magadan, 2011,
17, Asia/Kamchatka, 2011,
17, Asia/Anadyr, 2011,
17, Asia/Sakhalin, 2011,
17, America/Metlakatla, 1984,
17, Europe/Kaliningrad, 2011,
17, Europe/Moscow, 2011,
17, Europe/Samara, 2011,
17, Europe/Volgograd, 2011,
17, Pacific/Apia, 2011,
17, Canada/Newfoundland, 2011,
17, W-SU, 2011,

Timezones added:
Africa/Juba

------ End of updates in Content version 17 ----


Current Structure version: 3
Current Content Version  :16

Content Version 16
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
16, Africa/Cairo, 2011,
16, Africa/Casablanca, 2011,
16, America/Juneau, 1980, 1980
16, America/Havana, 2011, 2011
16, America/Santiago, 2011, 2011
16, Asia/Amman, 2002,
16, Atlantic/Stanley, 2011, 2012
16, Europe/Istanbul, 2011, 2011
16, Pacific/Honolulu, 1896,
16, Pacific/Easter, 2011, 2011
16, Pacific/Apia, 2011,
16, Egypt, 2011,
16, Cuba, 2011, 2011
16, Chile/Continental, 2011, 2011
16, Turkey, 2011, 2011
16, US/Hawaii, 1896,
16, Chile/EasterIsland, 2011, 2011
16, Asia/Istanbul, 2011, 2011

Timezones added:
America/North_Dakota/Beulah
America/Metlakatla
America/Sitka

------ End of updates in Content version 16 ---

Current Structure version: 3
Current Content Version  :15

Content Version 15
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
15, Africa/Cairo,2010,2010
15, America/Bahia_Banderas,2010,2010
15, Asia/Hong_Kong,1977,1977
15, Asia/Amman,2002,
15, Asia/Gaza,2010,2010
15, Europe/Helsinki,1981,1982
15, Pacific/Fiji,2011,
15, Pacific/Apia,2011,
15, Egypt,2010,2010
15, Hongkong,1977,1977
15, Europe/Mariehamn,1981,1982

Timezones added:
Pacific/Chuuk
Pacific/Pohnpei

------ End of updates in Content version 15 ---

Current Structure version: 3
Current Content Version  :14

Content Version 14
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
14, Africa/Casablanca, 2010,
14, Africa/Tunis, 2010,
14, America/Argentina/San_Luis, 2010,
14, America/Tijuana, 2010,
14, America/Santiago, 2010, 2010
14, America/Asuncion, 2010,
14, Antarctica/Casey, 2010,
14, Antarctica/Davis, 2010,
14, Asia/Dacca, 2009,
14, Asia/Taipei, 1979,
14, Asia/Karachi, 2010,
14, Asia/Gaza, 2010,
14, Asia/Damascus, 2010,
14, Asia/Kamchatka, 2010,
14, Asia/Anadyr, 2010,
14, Europe/Samara, 2010,
14, Pacific/Easter, 2010, 2010
14, Pacific/Fiji, 2010,
14, Pacific/Apia, 2009,
14, America/Ensenada, 2010,
14, Chile/Continental, 2010, 2010
14, Asia/Dhaka, 2009,
14, ROC, 1979,
14, Chile/EasterIsland, 2010, 2010
14, Mexico/BajaNorte, 2010,

Timezones added:
America/Bahia_Banderas
America/Matamoros
America/Ojinaga
America/Santa_Isabel
Antarctica/Macquarie

------ End of updates in Content version 14 ---

Current Structure version: 3
Current Content Version  :13

Content Version 13
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
13, Africa/Cairo, 2009, 2009
13, America/Argentina/San_Luis, 2008,
13, America/Buenos_Aires, 2009,
13, America/Cordoba, 2009,
13, America/Catamarca, 1894, 1920
13, America/Catamarca, 1990, 2004
13, America/Argentina/Tucuman, 2009,
13, Antarctica/Casey, 2009,
13, Antarctica/Davis, 2009,
13, Antarctica/Mawson, 2009,
13, Asia/Dacca, 2009,
13, Asia/Hong_Kong, 1941, 1946
13, Asia/Hong_Kong, 1952, 1952
13, Asia/Hong_Kong, 1973, 1974
13, Asia/Hong_Kong, 1979,
13, Asia/Karachi, 2010,
13, Asia/Gaza, 2009,
13, Asia/Damascus, 2009,
13, Europe/Samara, 1989, 1992
13, Indian/Mauritius, 2009,
13, Pacific/Fiji, 2009,
13, Pacific/Auckland, 1867, 1929
13, Pacific/Auckland, 1940, 1974
13, Pacific/Chatham, 1800, 1990
13, Pacific/Apia, 2009,
13, Egypt, 2009, 2009
13, America/Argentina/Buenos_Aires, 2009,
13, America/Argentina/Cordoba, 2009,
13, America/Argentina/Catamarca, 1894, 1920
13, America/Argentina/Catamarca, 1990, 2004
13, Asia/Dhaka, 2009,
13, Hongkong, 1941, 1946
13, Hongkong, 1952, 1952
13, Hongkong, 1973, 1974
13, Hongkong, 1979,
13, NZ, 1867, 1929
13, NZ, 1940, 1974
13, NZ-CHAT, 1800, 1990
13, America/Rosario, 2009,
13, America/Argentina/ComodRivadavia, 1894, 1920
13, America/Argentina/ComodRivadavia, 1990, 2004 

Timezones added:
no new zones are added

------ End of updates in Content version 13 ---

Current Structure version: 3
Current Content Version  :12

Content Version 12
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
12, Africa/Algiers, 1977, 1978
12, America/Recife, 1999, 1999
12, America/North_Dakota/Center, 1992, 1993
12, America/North_Dakota/New_Salem, 2003, 2004
12, America/Kentucky/Monticello, 1968, 1968
12, America/Kentucky/Monticello, 2000, 2001
12, America/Indiana/Tell_City, 2006, 2006
12, America/Argentina/Rio_Gallegos, 1999, 2000
12, America/Argentina/La_Rioja, 1999, 2000
12, America/Juneau, 1969, 1969
12, America/Juneau, 1983, 1983
12, America/Yakutat, 1969, 1969
12, America/Anchorage, 1983, 1983
12, America/Nome, 1983, 1983
12, America/Adak, 1983, 1983
12, America/Indianapolis, 2006, 2006
12, America/Indiana/Marengo, 2006, 2006
12, America/Indiana/Knox, 1991, 2006
12, America/Indiana/Vevay, 2006, 2006
12, America/Louisville, 1949, 1950
12, America/Menominee, 1973, 1973
12, America/Glace_Bay, 1972, 1972
12, America/Thunder_Bay, 1974, 1974
12, America/Pangnirtung, 1995, 1995
12, America/Pangnirtung, 1999, 2001
12, America/Iqaluit, 1999, 2001
12, America/Rankin_Inlet, 2000, 2001
12, America/Cambridge_Bay, 1999, 2000
12, America/Mexico_City, 2002, 2002
12, America/Tijuana, 1976, 1976
12, America/Buenos_Aires, 1999, 2000
12, America/Argentina/Ushuaia, 1999, 2000
12, America/Cordoba, 1991, 1991
12, America/Cordoba, 1999, 2000
12, America/Jujuy, 1990, 1990
12, America/Jujuy, 1999,
12, America/Catamarca, 1991, 1991
12, America/Mendoza, 1990, 1990
12, America/Mendoza, 1999, 2000
12, America/Noronha, 1999, 1999
12, America/Fortaleza, 1999, 1999
12, America/Araguaina, 1995, 1995
12, America/Maceio, 1995, 1999
12, America/Cuiaba, 2004, 2004
12, America/Boa_Vista, 1999, 1999
12, America/Manaus, 1993,
12, America/Santiago, 1927, 1928
12, America/Indiana/Vincennes, 2006, 2008
12, America/Indiana/Petersburg, 1977, 2008
12, America/Indiana/Winamac, 2006, 2006
12, America/Resolute, 2000, 2001
12, America/Resolute, 2006, 2007
12, America/Eirunepe, 1993,
12, America/Argentina/Tucuman, 1991, 1991
12, America/Argentina/Tucuman, 1999, 2000
12, America/Argentina/San_Juan, 1999, 2000
12, America/Argentina/Salta, 1991, 1991
12, America/Argentina/Salta, 1999,
12, Asia/Tbilisi, 1994, 1997
12, Asia/Almaty, 1991, 1992
12, Asia/Aqtobe, 1982, 1982
12, Asia/Aqtau, 1982, 1982
12, Asia/Aqtau, 1995, 1995
12, Asia/Ashgabat, 1991,
12, Asia/Samarkand, 1982, 1982
12, Asia/Tashkent, 1991,
12, Asia/Anadyr, 1982, 1982
12, Asia/Anadyr, 1991, 1991
12, Asia/Qyzylorda, 1982, 1982
12, Asia/Oral, 1982, 1982
12, Asia/Oral, 1989, 1989
12, Asia/Sakhalin, 1991, 1991
12, Asia/Sakhalin, 1997, 1997
12, Atlantic/Stanley, 1985, 1986
12, Europe/Tallinn, 2002, 2002
12, Europe/Paris, 1945, 1976
12, Europe/Riga, 2001, 2001
12, Europe/Monaco, 1945, 1976
12, Europe/Amsterdam, 1937, 1937
12, Europe/Warsaw, 1918, 1919
12, Europe/Moscow, 1919, 1919
12, Europe/Madrid, 1946, 1949
12, Europe/Istanbul, 1985, 1985
12, Europe/Volgograd, 1989, 1989
12, Pacific/Easter, 1982, 1982
12, US/Alaska, 1983, 1983
12, America/Atka, 1983, 1983
12, America/Fort_Wayne, 2006, 2006
12, America/Knox_IN, 1991, 2006
12, America/Kentucky/Louisville, 1949, 1950
12, Mexico/General, 2002, 2002
12, America/Ensenada, 1976, 1976
12, America/Argentina/Buenos_Aires, 1999, 2000
12, America/Argentina/Cordoba, 1991, 1991
12, America/Argentina/Cordoba, 1999, 2000
12, America/Argentina/Jujuy, 1990, 1990
12, America/Argentina/Jujuy, 1999,
12, America/Argentina/Catamarca, 1991, 1991
12, America/Argentina/Mendoza, 1990, 1990
12, America/Argentina/Mendoza, 1999, 2000
12, Brazil/DeNoronha, 1999, 1999
12, Brazil/West, 1993,
12, Chile/Continental, 1927, 1928
12, Asia/Ashkhabad, 1991,
12, Poland, 1918, 1919
12, W-SU, 1919, 1919
12, Turkey, 1985, 1985
12, Chile/EasterIsland, 1982, 1982
12, US/Aleutian, 1983, 1983
12, US/East-Indiana, 2006, 2006
12, US/Indiana-Starke, 1991, 2006
12, Mexico/BajaNorte, 1976, 1976
12, America/Rosario, 1991, 1991
12, America/Rosario, 1999, 2000
12, America/Argentina/ComodRivadavia, 1991, 1991
12, Asia/Istanbul, 1985, 1985
12, America/Indiana/Indianapolis, 2006, 2006

Timezones added:
no new zones are added

------ End of updates in Content version 12 ---

Current Structure version: 3
Current Content Version  :11

Content Version 11
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
11, Africa/Cairo, 2009,
11, Africa/Nairobi, 1939,
11, Africa/Casablanca, 2009,
11, Africa/Dar_es_Salaam, 1947,
11, Africa/Tunis, 2009, 2010
11, Africa/Kampala, 1947,
11, America/North_Dakota/Center, 1945, 1945
11, America/North_Dakota/New_Salem, 1945, 1945
11, America/Kentucky/Monticello, 1945, 1945
11, America/Moncton, 1945, 1945
11, America/Indiana/Tell_City, 1945, 1945
11, America/Argentina/San_Luis, 1967, 1967
11, America/Argentina/San_Luis, 1974, 1988
11, America/Argentina/San_Luis, 2009,
11, America/Argentina/Rio_Gallegos, 1967, 1967
11, America/Argentina/Rio_Gallegos, 1974, 1988
11, America/Argentina/La_Rioja, 1967, 1967
11, America/Argentina/La_Rioja, 1974, 1988
11, America/New_York, 1883, 1883
11, America/New_York, 1945, 1945
11, America/Chicago, 1883, 1883
11, America/Chicago, 1945, 1945
11, America/Denver, 1883, 1883
11, America/Denver, 1945, 1945
11, America/Los_Angeles, 1883, 1883
11, America/Los_Angeles, 1945, 1945
11, America/Juneau, 1800, 1945
11, America/Juneau, 1983, 1984
11, America/Yakutat, 1800, 1945
11, America/Yakutat, 1983, 1983
11, America/Anchorage, 1800, 1945
11, America/Anchorage, 1983, 1984
11, America/Nome, 1800, 1945
11, America/Nome, 1983, 1984
11, America/Adak, 1800, 1945
11, America/Adak, 1983, 1984
11, America/Phoenix, 1883, 1883
11, America/Phoenix, 1944,
11, America/Boise, 1883, 1883
11, America/Boise, 1945, 1945
11, America/Indianapolis, 1945, 1945
11, America/Indiana/Marengo, 1883, 1883
11, America/Indiana/Marengo, 1945, 1945
11, America/Indiana/Knox, 1883, 1883
11, America/Indiana/Knox, 1945, 1945
11, America/Indiana/Vevay, 1883, 1883
11, America/Indiana/Vevay, 1945, 1945
11, America/Louisville, 1883, 1883
11, America/Louisville, 1945, 1945
11, America/Detroit, 1945, 1945
11, America/Menominee, 1945, 1945
11, America/St_Johns, 1945, 1945
11, America/Goose_Bay, 1945, 1945
11, America/Halifax, 1945, 1945
11, America/Glace_Bay, 1945, 1945
11, America/Montreal, 1942, 1945
11, America/Thunder_Bay, 1895, 1945
11, America/Nipigon, 1940, 1945
11, America/Rainy_River, 1800, 1945
11, America/Winnipeg, 1966, 1986
11, America/Regina, 1945, 1945
11, America/Regina, 1958,
11, America/Swift_Current, 1945, 1945
11, America/Edmonton, 1945, 1945
11, America/Vancouver, 1945, 1945
11, America/Dawson_Creek, 1945, 1945
11, America/Pangnirtung, 1800, 1945
11, America/Iqaluit, 1800, 1945
11, America/Rankin_Inlet, 1800, 1957
11, America/Cambridge_Bay, 1800, 1945
11, America/Yellowknife, 1800, 1945
11, America/Inuvik, 1800, 1953
11, America/Whitehorse, 1945, 1945
11, America/Dawson, 1945, 1945
11, America/Tijuana, 1945, 1945
11, America/Havana, 2006, 2006
11, America/Havana, 2009,
11, America/Martinique, 1890,
11, America/Managua, 1890, 1934
11, America/Managua, 1992, 1998
11, America/Panama, 1890,
11, America/Puerto_Rico, 1945,
11, America/Miquelon, 1980, 1987
11, America/Grand_Turk, 1979, 2006
11, America/Buenos_Aires, 1967, 1967
11, America/Buenos_Aires, 1974, 1988
11, America/Argentina/Ushuaia, 1967, 1967
11, America/Argentina/Ushuaia, 1974, 1988
11, America/Cordoba, 1800, 1920
11, America/Cordoba, 1967, 1967
11, America/Cordoba, 1974, 1988
11, America/Cordoba, 1990, 2007
11, America/Jujuy, 1894, 1920
11, America/Jujuy, 1967, 1967
11, America/Jujuy, 1974, 1988
11, America/Jujuy, 1990,
11, America/Catamarca, 1967, 1967
11, America/Catamarca, 1974, 1988
11, America/Mendoza, 1894, 1894
11, America/Mendoza, 1967, 1967
11, America/Mendoza, 1974, 1988
11, America/Mendoza, 1990, 2004
11, America/Noronha, 1999,
11, America/Porto_Acre, 2008,
11, America/Santiago, 1800, 1927
11, America/Santiago, 1932, 1970
11, America/Santiago, 1973, 1973
11, America/Santiago, 1987, 1990
11, America/Santiago, 1997, 1997
11, America/Bogota, 1992,
11, America/Lima, 1890, 1908
11, America/Lima, 1986, 1987
11, America/Lima, 1993,
11, America/Montevideo, 1941, 1942
11, America/Caracas, 1890,
11, America/Scoresbysund, 1800, 1916
11, America/Thule, 1991, 1993
11, America/Indiana/Vincennes, 1945, 1945
11, America/Indiana/Petersburg, 1945, 1945
11, EST5EDT, 1945, 1945
11, CST6CDT, 1945, 1945
11, MST7MDT, 1945, 1945
11, PST8PDT, 1945, 1945
11, America/Indiana/Winamac, 1945, 1945
11, America/Resolute, 2007,
11, America/Toronto, 1942, 1945
11, America/Atikokan, 1942,
11, America/Blanc-Sablon, 1945,
11, America/Eirunepe, 2008,
11, America/Argentina/Tucuman, 1967, 1967
11, America/Argentina/Tucuman, 1974, 1988
11, America/Argentina/San_Juan, 1967, 1967
11, America/Argentina/San_Juan, 1974, 1988
11, Antarctica/Palmer, 1967, 1967
11, Antarctica/Palmer, 1974, 1982
11, Antarctica/Palmer, 1987, 1990
11, Antarctica/Palmer, 1997, 1997
11, America/Argentina/Salta, 1967, 1967
11, America/Argentina/Salta, 1974, 1988
11, America/Argentina/Salta, 2000,
11, Asia/Baku, 1992, 1996
11, Asia/Dili, 1945,
11, Asia/Jakarta, 1945,
11, Asia/Ujung_Pandang, 1945,
11, Asia/Jayapura, 1943,
11, Asia/Baghdad, 2008,
11, Asia/Amman, 1999,
11, Asia/Kuala_Lumpur, 1800,
11, Asia/Kuching, 1941,
11, Asia/Hovd, 1984, 1998
11, Asia/Ulaanbaatar, 1984, 1998
11, Asia/Karachi, 2009,
11, Asia/Gaza, 2008,
11, Asia/Manila, 1844, 1844
11, Asia/Singapore, 1800,
11, Asia/Damascus, 2009,
11, Asia/Samarkand, 1982,
11, Asia/Tashkent, 1992,
11, Asia/Yekaterinburg, 1800, 1957
11, Asia/Omsk, 1919, 1957
11, Asia/Novosibirsk, 1919, 1957
11, Asia/Novosibirsk, 1993, 1994
11, Asia/Krasnoyarsk, 1920, 1957
11, Asia/Irkutsk, 1920, 1957
11, Asia/Yakutsk, 1919, 1957
11, Asia/Vladivostok, 1879, 1981
11, Asia/Magadan, 1930, 1957
11, Asia/Kamchatka, 1922, 1957
11, Asia/Pontianak, 1945, 1945
11, Asia/Choibalsan, 1984, 1998
11, Atlantic/Azores, 1884, 1911
11, Atlantic/Madeira, 1884, 1911
11, CET, 1945, 1977
11, MET, 1945, 1977
11, Europe/Dublin, 1800, 1880
11, Europe/Vienna, 1918, 1918
11, Europe/Vienna, 1945, 1945
11, Europe/Vienna, 1980, 1981
11, Europe/Copenhagen, 1893, 1894
11, Europe/Berlin, 1945, 1947
11, Europe/Belfast, 1800, 1917
11, Europe/Chisinau, 1879, 1981
11, Europe/Chisinau, 1990, 1991
11, Europe/Amsterdam, 1800, 1937
11, Europe/Amsterdam, 1940, 1940
11, Europe/Amsterdam, 1945, 1945
11, Europe/Warsaw, 1944, 1957
11, Europe/Warsaw, 1988, 1998
11, Europe/Lisbon, 1911, 1912
11, Europe/Kaliningrad, 1992, 1994
11, Europe/Moscow, 1879, 1919
11, Europe/Samara, 1919, 1957
11, Europe/Samara, 1989, 1992
11, Europe/Samara, 1992, 1992
11, Europe/Stockholm, 1878, 1916
11, Europe/Zurich, 1940, 1942
11, Europe/Istanbul, 1991, 1999
11, Europe/Kiev, 1917, 1981
11, Europe/Kiev, 1990, 1992
11, Europe/Kiev, 1995, 1995
11, Europe/Simferopol, 1879, 1981
11, Europe/Simferopol, 1990, 1996
11, Indian/Chagos, 1800,
11, Indian/Cocos, 1800,
11, Indian/Mauritius, 1982, 2008
11, Pacific/Honolulu, 1945,
11, Pacific/Easter, 1800, 1970
11, Pacific/Easter, 1973, 1973
11, Pacific/Easter, 1982, 1982
11, Pacific/Easter, 1987, 1990
11, Pacific/Easter, 1997, 1997
11, Pacific/Port_Moresby, 1879,
11, Pacific/Midway, 1956,
11, Egypt, 2009,
11, US/Eastern, 1883, 1883
11, US/Eastern, 1945, 1945
11, US/Central, 1883, 1883
11, US/Central, 1945, 1945
11, Navajo, 1883, 1883
11, Navajo, 1945, 1945
11, US/Pacific, 1883, 1883
11, US/Pacific, 1945, 1945
11, US/Alaska, 1800, 1945
11, US/Alaska, 1983, 1984
11, America/Atka, 1800, 1945
11, America/Atka, 1983, 1984
11, US/Arizona, 1883, 1883
11, US/Arizona, 1944,
11, America/Fort_Wayne, 1945, 1945
11, America/Knox_IN, 1883, 1883
11, America/Knox_IN, 1945, 1945
11, America/Kentucky/Louisville, 1883, 1883
11, America/Kentucky/Louisville, 1945, 1945
11, US/Michigan, 1945, 1945
11, Canada/Newfoundland, 1945, 1945
11, Canada/Atlantic, 1945, 1945
11, Canada/Eastern, 1942, 1945
11, Canada/Central, 1966, 1986
11, Canada/East-Saskatchewan, 1945, 1945
11, Canada/East-Saskatchewan, 1958,
11, Canada/Mountain, 1945, 1945
11, Canada/Pacific, 1945, 1945
11, Canada/Yukon, 1945, 1945
11, America/Ensenada, 1945, 1945
11, Cuba, 2006, 2006
11, Cuba, 2009,
11, America/Argentina/Buenos_Aires, 1967, 1967
11, America/Argentina/Buenos_Aires, 1974, 1988
11, America/Argentina/Cordoba, 1800, 1920
11, America/Argentina/Cordoba, 1967, 1967
11, America/Argentina/Cordoba, 1974, 1988
11, America/Argentina/Cordoba, 1990, 2007
11, America/Argentina/Jujuy, 1894, 1920
11, America/Argentina/Jujuy, 1967, 1967
11, America/Argentina/Jujuy, 1974, 1988
11, America/Argentina/Jujuy, 1990,
11, America/Argentina/Catamarca, 1967, 1967
11, America/Argentina/Catamarca, 1974, 1988
11, America/Argentina/Mendoza, 1894, 1894
11, America/Argentina/Mendoza, 1967, 1967
11, America/Argentina/Mendoza, 1974, 1988
11, America/Argentina/Mendoza, 1990, 2004
11, Brazil/DeNoronha, 1999,
11, Brazil/Acre, 2008,
11, Chile/Continental, 1800, 1927
11, Chile/Continental, 1932, 1970
11, Chile/Continental, 1973, 1973
11, Chile/Continental, 1987, 1990
11, Chile/Continental, 1997, 1997
11, America/Coral_Harbour, 1942,
11, Asia/Makassar, 1945,
11, Asia/Ulan_Bator, 1984, 1998
11, Singapore, 1800,
11, Eire, 1800, 1880
11, Europe/Tiraspol, 1879, 1981
11, Europe/Tiraspol, 1990, 1991
11, Poland, 1944, 1957
11, Poland, 1988, 1998
11, Portugal, 1911, 1912
11, W-SU, 1879, 1919
11, Turkey, 1991, 1999
11, US/Hawaii, 1945,
11, Chile/EasterIsland, 1800, 1970
11, Chile/EasterIsland, 1973, 1973
11, Chile/EasterIsland, 1982, 1982
11, Chile/EasterIsland, 1987, 1990
11, Chile/EasterIsland, 1997, 1997
11, US/Mountain, 1883, 1883
11, US/Mountain, 1945, 1945
11, US/Aleutian, 1800, 1945
11, US/Aleutian, 1983, 1984
11, US/East-Indiana, 1945, 1945
11, US/Indiana-Starke, 1883, 1883
11, US/Indiana-Starke, 1945, 1945
11, Canada/Saskatchewan, 1945, 1945
11, Canada/Saskatchewan, 1958,
11, Mexico/BajaNorte, 1945, 1945
11, America/Rosario, 1800, 1920
11, America/Rosario, 1967, 1967
11, America/Rosario, 1974, 1988
11, America/Rosario, 1990, 2007
11, America/Argentina/ComodRivadavia, 1967, 1967
11, America/Argentina/ComodRivadavia, 1974, 1988
11, America/Rio_Branco, 2008,
11, Asia/Istanbul, 1991, 1999
11, CST, 1883, 1883
11, CST, 1945, 1945
11, America/Shiprock, 1883, 1883
11, America/Shiprock, 1945, 1945
11, US/Pacific-New, 1883, 1883
11, US/Pacific-New, 1945, 1945
11, America/Indiana/Indianapolis, 1945, 1945
11, PST, 1883, 1883
11, PST, 1945, 1945

Timezones added:
no new zones are added
------ End of updates in Content version 11 ---


Current Structure version: 3
Current Content Version  :10

Content Version 10
------------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
10, America/Argentina/Rio_Gallegos, 2008,
10, America/Argentina/La_Rioja, 2008,
10, America/Argentina/Ushuaia, 2008,
10, America/Jujuy, 2008,
10, America/Catamarca, 2008,
10, America/Mendoza, 2008,
10, America/Sao_Paulo, 2012, 2012
10, America/Sao_Paulo, 2015, 2015
10, America/Sao_Paulo, 2023, 2023
10, America/Sao_Paulo, 2026, 2026
10, America/Sao_Paulo, 2034, 2034
10, America/Sao_Paulo, 2037, 2037
10, America/Cuiaba, 2012, 2012
10, America/Cuiaba, 2015, 2015
10, America/Cuiaba, 2023, 2023
10, America/Cuiaba, 2026, 2026
10, America/Cuiaba, 2034, 2034
10, America/Cuiaba, 2037, 2037
10, America/Campo_Grande, 2012, 2012
10, America/Campo_Grande, 2015, 2015
10, America/Campo_Grande, 2023, 2023
10, America/Campo_Grande, 2026, 2026
10, America/Campo_Grande, 2034, 2034
10, America/Campo_Grande, 2037, 2037
10, America/Argentina/San_Juan, 2008,
10, Asia/Damascus, 2008,
10, Indian/Mauritius, 2009,
10, America/Argentina/Jujuy, 2008,
10, America/Argentina/Catamarca, 2008,
10, America/Argentina/Mendoza, 2008,
10, Brazil/East, 2012, 2012
10, Brazil/East, 2015, 2015
10, Brazil/East, 2023, 2023
10, Brazil/East, 2026, 2026
10, Brazil/East, 2034, 2034
10, Brazil/East, 2037, 2037
10, America/Argentina/ComodRivadavia, 2008,

Timezones added:
America/Argentina/Salta

------ End of updates in Content version 10 ----

Content Version 9
----------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
9, Africa/Casablanca, 2008,
9, America/Argentina/Rio_Gallegos, 2008,
9, America/Argentina/La_Rioja, 2008,
9, America/Havana, 2008,
9, America/Argentina/Ushuaia, 2008,
9, America/Cordoba, 2008,
9, America/Jujuy, 2008,
9, America/Catamarca, 2008,
9, America/Mendoza, 2008,
9, America/Sao_Paulo, 2008,
9, America/Cuiaba, 2008,
9, America/Santiago, 2008, 2008

Timezones added:
America/Argentina/ComodRivadavia
America/Argentina/San_Luis
America/Bahia
America/Coral_Harbour
America/Indiana/Tell_City
America/Indiana/Winamac
America/Kentucky/Monticello
America/Marigot
America/Moncton
America/North_Dakota/Center
America/North_Dakota/New_Salem
America/Recife
America/Resolute
America/St_Barthelemy
Asia/Ho_Chi_Minh
Asia/Kolkata
Asia/Oral
Asia/Qyzylorda
Asia/Sakhalin
Australia/Eucla

------ End of updates in Content version 9 ----

Current Structure version: 3
Current Content Version  :8

Content Version 8
----------------
Timezones updated:
none

Timezones added:
America/Argenina/Rio_Gallegos
America/Argentina/La_Rioja
America/Argentina/San_Juan
America/Argentina/Tucuman
America/Argentina/Ushuaia
America/Eirunepe
America/Merida
America/Monterrey
Asia/Pontianak

------ End of updates in Content version 8 ----
Current Structure version: 3
Current Content Version  :7

Content Version 7
----------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
7, America/Cuiaba, 2007,
7, America/Sao_Paulo, 2007,
7, Brazil/East, 2007,
7, Africa/Cairo, 2007,
7, Egypt, 2007,
7, America/Havana, 2007,
7, Cuba, 2007,
7, Antarctica/McMurdo, 2007,
7, Antarctica/South_Pole, 2007,
7, Asia/Gaza, 2007,
7, Asia/Damascus, 2007,
7, Australia/Adelaide, 2008,
7, Australia/South, 2008,
7, Australia/Hobart, 2008,
7, Australia/Tasmania, 2008,
7, Australia/Melbourne, 2008,
7, Australia/Victoria, 2008,
7, Australia/Sydney, 2008,
7, Australia/ACT, 2008,
7, Australia/Canberra, 2008,
7, Australia/NSW, 2008,
7, Australia/Broken_Hill, 2008,
7, Australia/Yancowinna, 2008,
7, Australia/Lord_Howe, 2008,
7, Australia/LHI, 2008,
7, America/Buenos_Aires, 2007,
7, America/Argentina/Buenos_Aires, 2007,
7, America/Cordoba, 2007,
7, America/Argentina/Cordoba, 2007,
7, America/Rosario, 2007,
7, America/Jujuy, 2007,
7, America/Argentina/Jujuy, 2007,
7, America/Catamarca, 2007,
7, America/Argentina/Catamarca, 2007,
7, America/Mendoza, 2007,
7, America/Argentina/Mendoza, 2007,
7, America/Caracas, 2007,
7, America/Indiana/Vincennes, 2007,
7, America/Indiana/Petersburg, 2007,
7, Asia/Tehran, 2008,
7, Iran, 2008,

Timezones added:
America/Toronto
America/Atikokan
America/Blanc-Sablon
America/Campo_Grande
America/Danmarkshavn
Australia/Currie

------ End of updates in Content version 7 -----

Current Structure version: 3
Current Content Version  :6

Content Version 6
-----------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
6, America/Grand_Turk, 2007,
6, America/Port-au-Prince, 2007,
6, NZ, 2007,
6, NZ-CHAT, 2007,
6, Pacific/Auckland, 2007,
6, Pacific/Chatham, 2007,

Timezones added:
no new zones are added 

------ End of updates in Content version 6 ------

Current Structure version: 3
Current Content Version  :5

Content Version 5
-----------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
5, America/Havana, 2007,
5, Cuba, 2007,
5, Europe/Istanbul, 2000, 2006
5, Turkey, 2000, 2006
5, Asia/Istanbul, 2000, 2006
5, Asia/Damascus, 2007,
5, America/Tegucigalpa, 2007, 2009

Timezones added:
Africa/Abidjan
Africa/Accra
Africa/Addis_Ababa
Africa/Asmara
Africa/Asmera
Africa/Bamako
Africa/Bangui
Africa/Banjul
Africa/Bissau
Africa/Blantyre
Africa/Brazzaville
Africa/Bujumbura
Africa/Conakry
Africa/Dakar
Africa/Dar_es_Salaam
Africa/Douala
Africa/El_Aaiun
Africa/Gaborone
Africa/Harare
Africa/Kampala
Africa/Kigali
Africa/Kinshasa
Africa/Lagos
Africa/Libreville
Africa/Lome
Africa/Luanda
Africa/Lubumbashi
Africa/Lusaka
Africa/Malabo
Africa/Maputo
Africa/Maseru
Africa/Mbabane
Africa/Monrovia
Africa/Ndjamena
Africa/Niamey
Africa/Ouagadougou
Africa/Porto-Novo
Africa/Sao_Tome
Africa/Timbuktu
America/Antigua
America/Argentina/Catamarca
America/Argentina/Cordoba
America/Argentina/Jujuy
America/Argentina/Mendoza
America/Barbados
America/Belize
America/Catamarca
America/Cordoba
America/Dominica
America/Glace_Bay
America/Grenada
America/Guyana
America/Jujuy
America/Mendoza
America/Menominee
America/Nassau
America/Nipigon
America/Pangnirtung
America/Paramaribo
America/Port-au-Prince
America/Port_of_Spain
America/Rainy_River
America/Rosario
America/Santo_Domingo
America/St_Kitts
America/St_Lucia
America/St_Vincent
America/Yakutat
Antarctica/Casey
Antarctica/Davis
Antarctica/DumontDUrville
Antarctica/Mawson
Antarctica/McMurdo
Antarctica/Palmer
Antarctica/South_Pole
Antarctica/Syowa
Asia/Ashgabat
Asia/Ashkhabad
Asia/Brunei
Asia/Choibalsan
Asia/Colombo
Asia/Dili
Asia/Dushanbe
Asia/Hovd
Asia/Katmandu
Asia/Phnom_Penh
Asia/Pyongyang
Asia/Samarkand
Asia/Thimbu
Asia/Thimphu
Asia/Ulaanbaatar
Asia/Ulan_Bator
Asia/Vientiane
Atlantic/Cape_Verde
Atlantic/Faroe
Atlantic/South_Georgia
Europe/Andorra
Europe/Chisinau
Europe/Malta
Europe/Tiraspol
Europe/Vaduz
Indian/Antananarivo
Indian/Comoro
Indian/Kerguelen
Indian/Mahe
Indian/Maldives
Indian/Mauritius
Pacific/Apia
Pacific/Efate
Pacific/Enderbury
Pacific/Funafuti
Pacific/Galapagos
Pacific/Guadalcanal
Pacific/Kosrae
Pacific/Majuro
Pacific/Nauru
Pacific/Palau
Pacific/Ponape
Pacific/Port_Moresby
Pacific/Tarawa
Pacific/Truk
Pacific/Yap

------ End of updates in Content version 5 ------

Current Structure version: 3
Current Content Version  :4

Content Version 4
-----------------
Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
4, Africa/Cairo, 2006, 2006
4, Egypt, 2006, 2006
4, Africa/Tunis, 2006,
4, Asia/Tehran, 2006,
4, Iran, 2006,
4, Asia/Amman, 2006,
4, Asia/Gaza, 2006,
4, Asia/Damascus, 2006,
4, Australia/Perth, 2006, 2009
4, Australia/West, 2006, 2009
4, America/St_Johns, 2007,
4, Canada/Newfoundland, 2007,
4, America/Whitehorse, 1981,
4, Canada/Yukon, 2007,
4, America/Edmonton, 1988,
4, Canada/Mountain, 2007,
4, America/Vancouver, 1988,
4, Canada/Pacific, 2007,
4, Atlantic/Bermuda, 1977,
4, America/Guatemala, 2006, 2006
4, America/Tegucigalpa, 1922,
4, America/Managua, 2006, 2006
4, America/Montevideo, 2006,
4, America/Sao_Paulo, 2006,
4, Brazil/East, 2006,
4, America/Goose_Bay, 2007,
4, America/Yellowknife, 1981,
4, America/Inuvik, 1981,
4, America/Dawson, 1981,
4, America/Cuiaba, 2006,
4, America/Thule, 2007,

Timezones added:
Europe/Podgorica
Europe/Jersey
Europe/Guernsey
Europe/Isle_of_Man
Europe/Volgograd

------ End of updates in Content version 4 ------

Current Structure version: 3
Current Content Version  : 3

Content Version 3
-----------------

Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
3, EST,1800,
3, MST,1800,
3, HST,1800,
3, EST5EDT,1800,
3, MST7MDT,1800,
3, CST6CDT,1800,
3, PST8PDT,1800,
3, Asia/Hong_Kong, 1998,
3, Hongkong, 1998,
3, Asia/Tehran, 2024, 2027
3, Iran, 2024, 2027
3, Asia/Jerusalem, 2025, 2037
3, Israel, 2025, 2037
3, Asia/Tel_Aviv, 2025, 2037
3, Asia/Tokyo, 1939,
3, Japan, 1939,
3, America/New_York, 2007,
3, US/Eastern, 2007,
3, America/Chicago, 2007,
3, US/Central, 2007,
3, America/Los_Angeles, 2007,
3, US/Pacific, 2007,
3, US/Pacific-New, 2007,
3, PST, 2007,
3, America/Anchorage, 2007,
3, US/Alaska, 2007,
3, America/Adak, 2007,
3, America/Atka, 2007,
3, US/Aleutian, 2007,
3, America/Indianapolis, 2006,
3, America/Fort_Wayne, 2006,
3, US/East-Indiana, 2006,
3, America/Indiana/Indianapolis, 2006,
3, America/Detroit, 2007,
3, US/Michigan, 2007,
3, America/Jamaica, 2007,
3, Jamaica, 2007,
3, America/Halifax, 1918,
3, Canada/Atlantic, 1918,
3, America/Montreal, 2007,
3, America/Montreal, 1974, 1974
3, Canada/Eastern, 2007,
3, Canada/Eastern, 1974, 1974
3, America/Winnipeg, 2007,
3, Canada/Central, 2007,
3, America/Havana, 2006,
3, Cuba, 2006,
3, America/Noronha, 2001,
3, Brazil/DeNoronha, 2001,
3, Africa/Khartoum, 2000,
3, Africa/Tunis, 2005,
3, Asia/Baku, 1997,
3, Asia/Chagos, 1998,
3, Asia/Tbilisi, 2004,
3, Asia/Jakarta, 1965,
3, Asia/Jayapura, 1965,
3, Asia/Amman, 2000,
3, Asia/Almaty, 2005,
3, Asia/Aqtobe, 2005,
3, Asia/Aqtau, 2005,
3, Asia/Bishkek, 2005,
3, Australia/Pitcairn, 1998,
3, America/Juneau, 2007,
3, America/Nome, 2007,
3, America/Boise, 2007,
3, America/Indiana/Marengo, 2006,
3, America/Indiana/Knox, 2006,
3, America/Knox_IN, 2006,
3, America/Indiana/Vevay, 2006,
3, America/Louisville, 2007,
3, America/Kentucky/Louisville, 2007,
3, America/Thunder_Bay, 2007,
3, America/Iqaluit, 2007,
3, America/Rankin_Inlet, 2007,
3, America/Cambridge_Bay, 2007,
3, America/Miquelon, 1987,
3, America/Managua, 2005, 2005
3, America/Cuiaba, 2004,
3, America/Asuncion, 1998,
3, America/Montevideo, 2003, 2006
3, America/Araguaina, 2003, 2003
3, America/Sao_Paulo, 2003,
3, Brazil/East, 2003,
3, Australia/Adelaide, 2006, 2006
3, Australia/South, 2006, 2006
3, Australia/Broken_Hill, 2006, 2006
3, Australia/Yancowinna, 2006, 2006
3, Australia/Hobart, 2006, 2006
3, Australia/Tasmania, 2006, 2006
3, Australia/Lord_Howe, 2006, 2006
3, Australia/LHI, 2006, 2006
3, Australia/Melbourne, 2006, 2006
3, Australia/Victoria, 2006, 2006
3, Australia/Sydney, 2006, 2006
3, Australia/ACT, 2006, 2006
3, Australia/Canberra, 2006, 2006
3, Australia/NSW, 2006, 2006

Timezones added:
EST
MST
HST
EST5EDT
CST6CDT
MST7MDT
PST8PDT
America/Indiana/Vincennes
America/Indiana/Petersburg

------ End of updates in Content version 3 ------

Current Structure version: 3
Current Content Version  : 2

Content Version 2
-----------------

Timezones updated:
DSTVERSION TIME_ZONE_NAME FROM_YEAR TO_YEAR
2, America/Havana, 2000,
2, Cuba, 2000,
2, America/Mazatlan, 1932, 1932
2, America/Mazatlan, 1942, 1942
2, America/Mazatlan, 2001, 2001
2, Mexico/BajaSur, 1932, 1932
2, Mexico/BajaSur, 1942, 1942
2, Mexico/BajaSur, 2001, 2001
2, America/Mexico_City, 1932, 1932
2, America/Mexico_City, 1943, 1943
2, America/Mexico_City, 2001, 2002
2, Mexico/General, 1932, 1932
2, Mexico/General, 1943, 1943
2, Mexico/General, 2001, 2002
2, America/Santiago, 1966, 1969
2, Chile/Continental, 1966, 1969
2, America/Sao_Paulo, 2000,
2, Brazil/East, 2000,
2, America/St_Johns, 1936, 1945
2, America/St_Johns, 1987,
2, Canada/Newfoundland, 1936, 1945
2, Canada/Newfoundland, 1987,
2, America/Winnipeg, 1942, 1942
2, America/Winnipeg, 1945, 1945
2, America/Winnipeg, 1987,
2, Canada/Central, 1942, 1942
2, Canada/Central, 1945, 1945
2, Canada/Central, 1987,
2, America/Tijuana, 1922, 1922
2, America/Tijuana, 1924, 1924
2, America/Tijuana, 1930, 1930
2, America/Tijuana, 1931, 1931
2, America/Tijuana, 1942, 1942
2, America/Tijuana, 1945, 1945
2, America/Tijuana, 1948, 1948
2, America/Tijuana, 1976, 1976
2, America/Ensenada, 1922, 1922
2, America/Ensenada, 1924, 1924
2, America/Ensenada, 1930, 1930
2, America/Ensenada, 1931, 1931
2, America/Ensenada, 1942, 1942
2, America/Ensenada, 1945, 1945
2, America/Ensenada, 1948, 1948
2, America/Ensenada, 1976, 1976
2, Asia/Jerusalem, 2000,
2, Israel, 2000,
2, Asia/Tel_Aviv, 2000,
2, Asia/Tehran, 1945,
2, Iran, 1945,
2, Australia/Lord_Howe, 1982,
2, Australia/LHI, 1982,
2, Pacific/Easter, 1996,
2, Chile/EasterIsland, 1996,
2, America/Araguaina, 2000,
2, America/Boa_Vista, 2000,
2, America/Buenos_Aires, 1894, 1894
2, America/Buenos_Aires, 1920, 1920
2, America/Buenos_Aires, 1967, 1967
2, America/Buenos_Aires, 1974, 1974
2, America/Buenos_Aires, 1988, 1988
2, America/Buenos_Aires, 1999, 2000
2, America/Cambridge_Bay, 1942, 1942
2, America/Cambridge_Bay, 1945, 1945
2, America/Cambridge_Bay, 2000,
2, America/Cancun, 1981, 1981
2, America/Cancun, 1996, 1997
2, America/Cancun, 2001, 2001
2, America/Chihuahua, 1932, 1932
2, America/Chihuahua, 2001, 2001
2, America/Cuiaba, 2000,
2, America/Fortaleza, 2000,
2, America/Goose_Bay, 1917, 1918
2, America/Goose_Bay, 1936, 1945
2, America/Goose_Bay, 1987,
2, America/Iqaluit, 1942, 1942
2, America/Iqaluit, 1945, 1945
2, America/Iqaluit, 2001,
2, America/Maceio, 2000,
2, America/Rankin_Inlet, 1942, 1942
2, America/Rankin_Inlet, 1945, 1945
2, America/Rankin_Inlet, 2000, 2000
2, Asia/Almaty, 1991,
2, Asia/Amman, 1999,
2, Asia/Anadyr, 1930, 1930
2, Asia/Anadyr, 1982,
2, Asia/Aqtau, 1991,
2, Asia/Aqtobe, 1924,
2, Asia/Baghdad, 1991,
2, Asia/Karachi, 2002, 2002
2, Atlantic/Stanley, 1996, 1996
2, Atlantic/Stanley, 2001,
2, Europe/Riga, 2000, 2001
2, Europe/Tallinn, 2002,
2, Europe/Vilnius, 2000, 2002
2, Pacific/Fiji, 2000,
2, Pacific/Guam, 1800, 1800
2, Pacific/Guam, 1844, 1844
2, Pacific/Guam, 2000, 2000
2, Pacific/Saipan, 1800, 1800
2, Pacific/Saipan, 1844, 1844
2, Pacific/Saipan, 2000, 2000
2, Pacific/Tongatapu, 1999,

Timezones added:
GMT-14
America/Rio_Branco (synonym for America/Porto_Acre)
Asia/Dhaka         (synonym for Asia/Dacca)
Asia/Chongqing     (synonym for Asia/Chungking)
Asia/Macau         (synonym for Asia/Macao)
Asia/Makassar      (synonym for Asia/Ujung_Pandang)

------ End of updates in Content version 2 ------
